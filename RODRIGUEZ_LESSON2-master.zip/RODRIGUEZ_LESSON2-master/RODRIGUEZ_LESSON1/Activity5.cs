﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace RODRIGUEZ_LESSON1
{
    public partial class Activity5 : Form
    {
        private Double basic_netincome = 0.00, basic_numhrs = 0.00, basic_rate = 0.00,
            hono_netincome = 0.00, hono_numhrs = 0.00, hono_rate = 0.00, other_netincome = 0.00,
            other_numhrs = 0.00, other_rate = 0.00;
        private Double netincome = 0.00, grossincome = 0.00, sss_contrib = 0.00,
            pagibig_contrib = 0.00, philhealth_contrib = 0.00, tax_contrib = 0.00, taxes = 0.00;
        private Double sss_loan = 0.00, pagibig_loan = 0.00, salary_loan = 0.00,
            salary_savings = 0.00, faculty_sav_loan = 0.00, other_deduction = 0.00,
            total_deduction = 0.00, total_contrib = 0.00, total_loan = 0.00;

        private void rate1txtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        

        private void pctxtbox_TextChanged(object sender, EventArgs e)
        {

        }

        

        private void tdtxtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void nhco1txtbox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                basic_numhrs = Convert.ToDouble(nhco1txtbox.Text);
                basic_rate = Convert.ToDouble(rate1txtbox.Text);
                basic_netincome = basic_numhrs * basic_rate;
                ico1txtbox.Text = basic_netincome.ToString("n");
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid input values!");
            }
        }

        

        private void button1_Click(object sender, EventArgs e)
        {

        }

        

        private void newtxtbox_Click(object sender, EventArgs e)
        {
            // clear
            employeetxtbox.Clear();
            fnametxtbox.Clear();
            mnametxtbox.Clear();
            snametxtbox.Clear();
            cstxtbox.Clear();
            dtxtbox.Clear();
            nodtxtbox.Clear();
            estxtbox.Clear();
            deptxtbox.Clear();
            rate1txtbox.Clear();
            rate2txtbox.Clear();
            rate3txtbox.Clear();
            ico1txtbox.Clear();
            ico2txtbox.Clear();
            ico3txtbox.Clear();
            nhco1txtbox.Clear();
            nhco3txtbox.Clear();
            nhco2txtbox.Clear();
            nitxtbox.Clear();
            gitxtbox.Clear();
            sssctxtbox.Clear();
            pctxtbox.Clear();
            phctxtbox.Clear();
            ttxtbox.Clear();
            sssltxtbox.Clear();
            piltxtbox.Clear();
        }

        

        private void nhco2txtbox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                hono_numhrs = Convert.ToDouble(nhco2txtbox.Text);
                hono_rate = Convert.ToDouble(rate2txtbox.Text);
                hono_netincome = hono_numhrs * hono_rate;
                ico2txtbox.Text = hono_netincome.ToString("n");
            }
            catch
            {
                MessageBox.Show("Invalid input values!");
            }
        }

        private void nhco3txtbox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                other_numhrs = Convert.ToDouble(nhco3txtbox.Text);
                other_rate = Convert.ToDouble(rate3txtbox.Text);
                other_netincome = other_numhrs * other_rate;
                ico3txtbox.Text = other_netincome.ToString("n");
                grossincome = basic_netincome + hono_netincome + other_netincome;
                gitxtbox.Text = grossincome.ToString();
            }
            catch
            {
                MessageBox.Show("Invalid input values!");
            }
        }

        


        private void button3_Click(object sender, EventArgs e)
        {
            // net income
            netincome = grossincome - total_deduction;
            nitxtbox.Text = netincome.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // gross income
            grossincome = basic_netincome + hono_netincome + other_netincome;
            gitxtbox.Text = grossincome.ToString();
            // sss contri
            if (grossincome < 5250)
            {
                sssctxtbox.Text = "250.00";
            }
            else if (grossincome > 5250 && grossincome <= 5749.99)
            {
                sssctxtbox.Text = "275.00";
            }
            else if (grossincome > 5750 && grossincome <= 6249.99)
            {
                sssctxtbox.Text = "300.00";
            }
            else if (grossincome > 6250 && grossincome <= 6749.99)
            {
                sssctxtbox.Text = "325.00";
            }
            else if (grossincome > 6750 && grossincome <= 7249.99)
            {
                sssctxtbox.Text = "350.00";
            }
            else if (grossincome > 7250 && grossincome <= 7749.99)
            {
                sssctxtbox.Text = "375.00";
            }
            else if (grossincome > 7750 && grossincome <= 8249.99)
            {
                sssctxtbox.Text = "400.00";
            }
            else if (grossincome > 8250 && grossincome <= 8749.99)
            {
                sssctxtbox.Text = "425.00";
            }
            else if (grossincome > 8750 && grossincome <= 9249.99)
            {
                sssctxtbox.Text = "450.00";
            }
            else if (grossincome > 9250 && grossincome <= 9749.99)
            {
                sssctxtbox.Text = "475.00";
            }
            else if (grossincome > 9750 && grossincome <= 10249.99)
            {
                sssctxtbox.Text = "500.00";
            }
            else if (grossincome > 10250 && grossincome <= 10749.99)
            {
                sssctxtbox.Text = "525.00";
            }
            else if (grossincome > 10750 && grossincome <= 11249.99)
            {
                sssctxtbox.Text = "550.00";
            }
            else if (grossincome > 11250 && grossincome <= 11749.99)
            {
                sssctxtbox.Text = "575.00";
            }
            else if (grossincome > 11750 && grossincome <= 12249.99)
            {
                sssctxtbox.Text = "600.00";
            }
            else if (grossincome > 12250 && grossincome <= 12749.99)
            {
                sssctxtbox.Text = "625.00";
            }
            else if (grossincome > 12750 && grossincome <= 13249.99)
            {
                sssctxtbox.Text = "650.00";
            }
            else if (grossincome > 13250 && grossincome <= 13749.99)
            {
                sssctxtbox.Text = "675.00";
            }
            else if (grossincome > 13750 && grossincome <= 14249.99)
            {
                sssctxtbox.Text = "700.00";
            }
            else if (grossincome > 14250 && grossincome <= 14749.99)
            {
                sssctxtbox.Text = "725.00";
            }
            else if (grossincome > 14750 && grossincome <= 15249.99)
            {
                sssctxtbox.Text = "750.00";
            }
            else if (grossincome > 15250 && grossincome <= 15749.99)
            {
                sssctxtbox.Text = "775.00";
            }
            else if (grossincome > 15750 && grossincome <= 16249.99)
            {
                sssctxtbox.Text = "800.00";
            }
            else if (grossincome > 16250 && grossincome <= 16749.99)
            {
                sssctxtbox.Text = "825.00";
            }
            else if (grossincome > 16750 && grossincome <= 17249.99)
            {
                sssctxtbox.Text = "850.00";
            }
            else if (grossincome > 17250 && grossincome <= 17749.99)
            {
                sssctxtbox.Text = "875.00";
            }
            else if (grossincome > 17750 && grossincome <= 18249.99)
            {
                sssctxtbox.Text = "900.00";
            }
            else if (grossincome > 18250 && grossincome <= 18749.99)
            {
                sssctxtbox.Text = "925.00";
            }
            else if (grossincome > 18750 && grossincome <= 19249.99)
            {
                sssctxtbox.Text = "950.00";
            }
            else if (grossincome > 19250 && grossincome <= 19749.99)
            {
                sssctxtbox.Text = "975.00";
            }
            else if (grossincome > 19750 && grossincome <= 20249.99)
            {
                sssctxtbox.Text = "1000.00";
            }
            else
            {
                sssctxtbox.Text = "1000.00";
            }
            // tax income
            if (grossincome < (250000 / 24))
            {
                ttxtbox.Text = "0";
            }
            else if (grossincome > 10416.67 && grossincome <= 16666.67)
            {
                taxes = ((((grossincome * 24) - 250000) * 0.20) / 24);
                ttxtbox.Text = taxes.ToString("n");
            }
            else if (grossincome > 16666.67 && grossincome <= 33333.33)
            {
                taxes = (((((grossincome * 24) - 400000) * 0.25) + 30000) / 24); 
                ttxtbox.Text = taxes.ToString("n");
            }
            else if (grossincome > 33333.33 && grossincome <= 83333.33)
            {
                taxes = (((((grossincome * 24) - 800000) * 0.30) +130000)/ 24); 
                ttxtbox.Text = taxes.ToString("n");
            }
            else if (grossincome > 83333.33 && grossincome <= 333333.33)
            {
                taxes = (((((grossincome * 24) - 2000000) * 0.32) + 490000) / 24); 
                ttxtbox.Text = taxes.ToString("n");
            }
            else
            {
                taxes = (((((grossincome * 24) - 8000000) * 0.35) + 2410000) / 24); 
                ttxtbox.Text = taxes.ToString("n");
            }
            // philhealt contri
            if (grossincome < 100000)
            {
                phctxtbox.Text = Convert.ToString(grossincome * .05);
            }
            else
            {
                phctxtbox.Text = Convert.ToString("5000");
            }
            // pagibig contri
            pctxtbox.Text = "200.00";

            // convert
            sss_contrib = Convert.ToDouble(sssctxtbox.Text);
            pagibig_contrib = Convert.ToDouble(pctxtbox.Text);
            philhealth_contrib = Convert.ToDouble(phctxtbox.Text);
            tax_contrib = Convert.ToDouble(ttxtbox.Text);
            sss_loan = Convert.ToDouble(sssltxtbox.Text);
            pagibig_loan = Convert.ToDouble(piltxtbox.Text);
            salary_loan = Convert.ToDouble(sltxtbox.Text);
            other_deduction = Convert.ToDouble(otxtbox.Text);
            // total deduc
            total_contrib = sss_contrib + pagibig_contrib + philhealth_contrib + tax_contrib;
            total_loan = sss_loan + pagibig_loan + salary_loan + faculty_sav_loan + salary_savings + other_deduction;
            total_deduction = total_contrib + total_loan + 750;
            tdtxtbox.Text = Convert.ToString(total_deduction);
            }

        
        public Activity5()
        {
            InitializeComponent();
        }

        private void estxtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // print 
            Activity5_PrintFrm print = new Activity5_PrintFrm();
            print.deptbox.Text = deptxtbox.Text;
            print.pptbox.Text = dateTimePicker1.Text;
            print.cutofftbox.Text = dateTimePicker1.Text;
            print.empcodetbox.Text = employeetxtbox.Text;
            print.empnametbox.Text = fnametxtbox.Text + " " + mnametxtbox.Text + " " + snametxtbox.Text;
            print.textBox1.Text = "Lyceum of the Philippines University Cavite";
            print.bphrstbox.Text = nhco1txtbox.Text;
            print.overtimehrstbox.Text = nhco2txtbox.Text;
            print.honorhrstbox.Text = nhco3txtbox.Text;
            print.textBox18.Text = "0";
            print.textBox21.Text = "0";
            print.textBox24.Text = "0";
            print.textBox28.Text = ttxtbox.Text;
            print.textBox27.Text = sssctxtbox.Text;
            print.textBox26.Text = pctxtbox.Text;
            print.textBox25.Text = phctxtbox.Text;
            print.textBox29.Text = "750";
            print.textBox2.Text = gitxtbox.Text;
            print.textBox3.Text = tdtxtbox.Text;
            /*print.textBox4.Text =*/
            print.textBox5.Text = gitxtbox.Text;
            print.textBox6.Text = tdtxtbox.Text;
            print.textBox7.Text = nitxtbox.Text;
            print.textBox4.Text = ico3txtbox.Text;
            print.Show();
        }

        private void Activity5_Load(object sender, EventArgs e)
        {
            // default
            ico1txtbox.Text = "0.00";
            ico2txtbox.Text = "0.00";
            ico3txtbox.Text = "0.00";
            gitxtbox.Text = "0.00";
            nitxtbox.Text = "0.00";
            tdtxtbox.Text = "0.00";
            ico1txtbox.Enabled = false;
            ico2txtbox.Enabled = false;
            ico3txtbox.Enabled = false;
            nitxtbox.Enabled = false;
            gitxtbox.Enabled = false;
            tdtxtbox.Enabled = false;
            sssctxtbox.Enabled = false;
            phctxtbox.Enabled = false;
            pctxtbox.Enabled = false;
            ttxtbox.Enabled = false;
            sssctxtbox.Text = "0.00";
            pctxtbox.Text = "0.00";
            phctxtbox.Text = "0.00";
            ttxtbox.Text = "0.00";
            sssltxtbox.Text = "0.00";
            piltxtbox.Text = "0.00";
            fsdtxtbox.Text = "0.00";
            fsltxtbox.Text = "0.00";
            sltxtbox.Text = "0.00";
            otxtbox.Text = "0.00";

            this.WindowState = FormWindowState.Maximized;
        }
    }
}

