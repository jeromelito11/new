﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RODRIGUEZ_LESSON1
{
    public partial class Activity3_transfer : Form
    {
        public Activity3_transfer()
        {
            InitializeComponent();
        }

        public void Activity3_transfer_Load(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        public void price1tbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
