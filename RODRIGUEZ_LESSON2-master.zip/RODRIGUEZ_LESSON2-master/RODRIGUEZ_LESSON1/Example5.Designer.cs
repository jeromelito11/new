﻿namespace RODRIGUEZ_LESSON1
{
    partial class Example5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.deptxtbox = new System.Windows.Forms.TextBox();
            this.estxtbox = new System.Windows.Forms.TextBox();
            this.nodtxtbox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dtxtbox = new System.Windows.Forms.TextBox();
            this.cstxtbox = new System.Windows.Forms.TextBox();
            this.snametxtbox = new System.Windows.Forms.TextBox();
            this.mnametxtbox = new System.Windows.Forms.TextBox();
            this.fnametxtbox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.employeetxtbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ipco1txtbox = new System.Windows.Forms.TextBox();
            this.nhco1txtbox = new System.Windows.Forms.TextBox();
            this.rate1txtbox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.thptxtbox = new System.Windows.Forms.TextBox();
            this.nhco2txtbox = new System.Windows.Forms.TextBox();
            this.rate2txtbox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.toiptxtbox = new System.Windows.Forms.TextBox();
            this.nhco3txtbox = new System.Windows.Forms.TextBox();
            this.rate3txtbox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.nitxtbox = new System.Windows.Forms.TextBox();
            this.gitxtbox = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ttxtbox = new System.Windows.Forms.TextBox();
            this.pctxtbox = new System.Windows.Forms.TextBox();
            this.phctxtbox = new System.Windows.Forms.TextBox();
            this.sssctxtbox = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.octxtbox = new System.Windows.Forms.ComboBox();
            this.otxtbox = new System.Windows.Forms.TextBox();
            this.sltxtbox = new System.Windows.Forms.TextBox();
            this.fsltxtbox = new System.Windows.Forms.TextBox();
            this.fsdtxtbox = new System.Windows.Forms.TextBox();
            this.piltxtbox = new System.Windows.Forms.TextBox();
            this.sssltxtbox = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tdtxtbox = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.browsetxtbox = new System.Windows.Forms.Button();
            this.calctxtbox = new System.Windows.Forms.Button();
            this.newtxtbox = new System.Windows.Forms.Button();
            this.canceltxtbox = new System.Windows.Forms.Button();
            this.printtxtbox = new System.Windows.Forms.Button();
            this.previewtxtbox = new System.Windows.Forms.Button();
            this.exittxtbox = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.deptxtbox);
            this.groupBox1.Controls.Add(this.estxtbox);
            this.groupBox1.Controls.Add(this.nodtxtbox);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.dtxtbox);
            this.groupBox1.Controls.Add(this.cstxtbox);
            this.groupBox1.Controls.Add(this.snametxtbox);
            this.groupBox1.Controls.Add(this.mnametxtbox);
            this.groupBox1.Controls.Add(this.fnametxtbox);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.employeetxtbox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(8, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(635, 195);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(371, 74);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(258, 22);
            this.dateTimePicker1.TabIndex = 19;
            // 
            // deptxtbox
            // 
            this.deptxtbox.Location = new System.Drawing.Point(390, 139);
            this.deptxtbox.Multiline = true;
            this.deptxtbox.Name = "deptxtbox";
            this.deptxtbox.Size = new System.Drawing.Size(239, 22);
            this.deptxtbox.TabIndex = 18;
            // 
            // estxtbox
            // 
            this.estxtbox.Location = new System.Drawing.Point(422, 105);
            this.estxtbox.Multiline = true;
            this.estxtbox.Name = "estxtbox";
            this.estxtbox.Size = new System.Drawing.Size(207, 22);
            this.estxtbox.TabIndex = 17;
            // 
            // nodtxtbox
            // 
            this.nodtxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nodtxtbox.Location = new System.Drawing.Point(402, 18);
            this.nodtxtbox.Multiline = true;
            this.nodtxtbox.Name = "nodtxtbox";
            this.nodtxtbox.Size = new System.Drawing.Size(227, 41);
            this.nodtxtbox.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(304, 145);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 16);
            this.label10.TabIndex = 15;
            this.label10.Text = "Department:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(304, 105);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(112, 16);
            this.label9.TabIndex = 14;
            this.label9.Text = "Employee Status:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(304, 74);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 16);
            this.label8.TabIndex = 13;
            this.label8.Text = "Paydate:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(304, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 32);
            this.label7.TabIndex = 12;
            this.label7.Text = "Number of \r\nDependant(s):";
            // 
            // dtxtbox
            // 
            this.dtxtbox.Location = new System.Drawing.Point(103, 155);
            this.dtxtbox.Multiline = true;
            this.dtxtbox.Name = "dtxtbox";
            this.dtxtbox.Size = new System.Drawing.Size(195, 22);
            this.dtxtbox.TabIndex = 11;
            // 
            // cstxtbox
            // 
            this.cstxtbox.Location = new System.Drawing.Point(87, 127);
            this.cstxtbox.Multiline = true;
            this.cstxtbox.Name = "cstxtbox";
            this.cstxtbox.Size = new System.Drawing.Size(211, 22);
            this.cstxtbox.TabIndex = 10;
            // 
            // snametxtbox
            // 
            this.snametxtbox.Location = new System.Drawing.Point(81, 99);
            this.snametxtbox.Multiline = true;
            this.snametxtbox.Name = "snametxtbox";
            this.snametxtbox.Size = new System.Drawing.Size(217, 22);
            this.snametxtbox.TabIndex = 9;
            // 
            // mnametxtbox
            // 
            this.mnametxtbox.Location = new System.Drawing.Point(103, 71);
            this.mnametxtbox.Multiline = true;
            this.mnametxtbox.Name = "mnametxtbox";
            this.mnametxtbox.Size = new System.Drawing.Size(195, 22);
            this.mnametxtbox.TabIndex = 8;
            // 
            // fnametxtbox
            // 
            this.fnametxtbox.Location = new System.Drawing.Point(81, 43);
            this.fnametxtbox.Multiline = true;
            this.fnametxtbox.Name = "fnametxtbox";
            this.fnametxtbox.Size = new System.Drawing.Size(217, 22);
            this.fnametxtbox.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 155);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Designation:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Civil Status:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Surname:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Middle Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Firstname:";
            // 
            // employeetxtbox
            // 
            this.employeetxtbox.Location = new System.Drawing.Point(135, 15);
            this.employeetxtbox.Multiline = true;
            this.employeetxtbox.Name = "employeetxtbox";
            this.employeetxtbox.Size = new System.Drawing.Size(163, 22);
            this.employeetxtbox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee Number:";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.ipco1txtbox);
            this.groupBox2.Controls.Add(this.nhco1txtbox);
            this.groupBox2.Controls.Add(this.rate1txtbox);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(8, 203);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(446, 113);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "BASIC PAY";
            this.groupBox2.Enter += new System.EventHandler(this.GroupBox2_Enter);
            // 
            // ipco1txtbox
            // 
            this.ipco1txtbox.Location = new System.Drawing.Point(160, 79);
            this.ipco1txtbox.Multiline = true;
            this.ipco1txtbox.Name = "ipco1txtbox";
            this.ipco1txtbox.Size = new System.Drawing.Size(280, 22);
            this.ipco1txtbox.TabIndex = 24;
            // 
            // nhco1txtbox
            // 
            this.nhco1txtbox.Location = new System.Drawing.Point(173, 51);
            this.nhco1txtbox.Multiline = true;
            this.nhco1txtbox.Name = "nhco1txtbox";
            this.nhco1txtbox.Size = new System.Drawing.Size(267, 22);
            this.nhco1txtbox.TabIndex = 23;
            this.nhco1txtbox.TextChanged += new System.EventHandler(this.Nhco1txtbox_TextChanged);
            // 
            // rate1txtbox
            // 
            this.rate1txtbox.Location = new System.Drawing.Point(126, 24);
            this.rate1txtbox.Multiline = true;
            this.rate1txtbox.Name = "rate1txtbox";
            this.rate1txtbox.Size = new System.Drawing.Size(314, 22);
            this.rate1txtbox.TabIndex = 20;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 82);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 16);
            this.label13.TabIndex = 22;
            this.label13.Text = "Income Per Cut Off:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(35, 54);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(132, 16);
            this.label12.TabIndex = 21;
            this.label12.Text = "No. of Hours / Cut Off:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(35, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 16);
            this.label11.TabIndex = 20;
            this.label11.Text = "Rate / Hour:";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox3.Controls.Add(this.thptxtbox);
            this.groupBox3.Controls.Add(this.nhco2txtbox);
            this.groupBox3.Controls.Add(this.rate2txtbox);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(8, 322);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(446, 113);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "HONORARUIM";
            // 
            // thptxtbox
            // 
            this.thptxtbox.Location = new System.Drawing.Point(182, 82);
            this.thptxtbox.Multiline = true;
            this.thptxtbox.Name = "thptxtbox";
            this.thptxtbox.Size = new System.Drawing.Size(258, 22);
            this.thptxtbox.TabIndex = 28;
            // 
            // nhco2txtbox
            // 
            this.nhco2txtbox.Location = new System.Drawing.Point(173, 49);
            this.nhco2txtbox.Multiline = true;
            this.nhco2txtbox.Name = "nhco2txtbox";
            this.nhco2txtbox.Size = new System.Drawing.Size(267, 22);
            this.nhco2txtbox.TabIndex = 27;
            this.nhco2txtbox.TextChanged += new System.EventHandler(this.Nhco2txtbox_TextChanged);
            // 
            // rate2txtbox
            // 
            this.rate2txtbox.Location = new System.Drawing.Point(126, 19);
            this.rate2txtbox.Multiline = true;
            this.rate2txtbox.Name = "rate2txtbox";
            this.rate2txtbox.Size = new System.Drawing.Size(314, 22);
            this.rate2txtbox.TabIndex = 26;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(35, 85);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(141, 16);
            this.label16.TabIndex = 25;
            this.label16.Text = "Total Honoraruim Pay:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(35, 52);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(132, 16);
            this.label15.TabIndex = 24;
            this.label15.Text = "No. of Hours / Cut Off:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(35, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 16);
            this.label14.TabIndex = 23;
            this.label14.Text = "Rate / Hour:";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox4.Controls.Add(this.toiptxtbox);
            this.groupBox4.Controls.Add(this.nhco3txtbox);
            this.groupBox4.Controls.Add(this.rate3txtbox);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(8, 441);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(446, 113);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "OTHER INCOME";
            // 
            // toiptxtbox
            // 
            this.toiptxtbox.Location = new System.Drawing.Point(191, 80);
            this.toiptxtbox.Multiline = true;
            this.toiptxtbox.Name = "toiptxtbox";
            this.toiptxtbox.Size = new System.Drawing.Size(249, 22);
            this.toiptxtbox.TabIndex = 31;
            // 
            // nhco3txtbox
            // 
            this.nhco3txtbox.Location = new System.Drawing.Point(173, 52);
            this.nhco3txtbox.Multiline = true;
            this.nhco3txtbox.Name = "nhco3txtbox";
            this.nhco3txtbox.Size = new System.Drawing.Size(267, 22);
            this.nhco3txtbox.TabIndex = 30;
            this.nhco3txtbox.TextChanged += new System.EventHandler(this.Nhco3txtbox_TextChanged);
            // 
            // rate3txtbox
            // 
            this.rate3txtbox.Location = new System.Drawing.Point(126, 26);
            this.rate3txtbox.Multiline = true;
            this.rate3txtbox.Name = "rate3txtbox";
            this.rate3txtbox.Size = new System.Drawing.Size(314, 22);
            this.rate3txtbox.TabIndex = 29;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(35, 83);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(150, 16);
            this.label19.TabIndex = 28;
            this.label19.Text = "Total Other Income Pay:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(35, 55);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(132, 16);
            this.label18.TabIndex = 27;
            this.label18.Text = "No. of Hours / Cut Off:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(35, 29);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(78, 16);
            this.label17.TabIndex = 26;
            this.label17.Text = "Rate / Hour:";
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox5.Controls.Add(this.nitxtbox);
            this.groupBox5.Controls.Add(this.gitxtbox);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(8, 560);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(446, 113);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "INCOME SUMMARY";
            // 
            // nitxtbox
            // 
            this.nitxtbox.Location = new System.Drawing.Point(135, 66);
            this.nitxtbox.Multiline = true;
            this.nitxtbox.Name = "nitxtbox";
            this.nitxtbox.Size = new System.Drawing.Size(305, 22);
            this.nitxtbox.TabIndex = 33;
            // 
            // gitxtbox
            // 
            this.gitxtbox.Location = new System.Drawing.Point(154, 33);
            this.gitxtbox.Multiline = true;
            this.gitxtbox.Name = "gitxtbox";
            this.gitxtbox.Size = new System.Drawing.Size(286, 22);
            this.gitxtbox.TabIndex = 32;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(35, 69);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(93, 16);
            this.label21.TabIndex = 17;
            this.label21.Text = "NET INCOME:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(35, 36);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(113, 16);
            this.label20.TabIndex = 16;
            this.label20.Text = "GROSS INCOME:";
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox6.Controls.Add(this.ttxtbox);
            this.groupBox6.Controls.Add(this.pctxtbox);
            this.groupBox6.Controls.Add(this.phctxtbox);
            this.groupBox6.Controls.Add(this.sssctxtbox);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(460, 203);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(446, 135);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "REGULARDEDUCTIONS";
            // 
            // ttxtbox
            // 
            this.ttxtbox.Location = new System.Drawing.Point(127, 104);
            this.ttxtbox.Multiline = true;
            this.ttxtbox.Name = "ttxtbox";
            this.ttxtbox.Size = new System.Drawing.Size(314, 22);
            this.ttxtbox.TabIndex = 24;
            // 
            // pctxtbox
            // 
            this.pctxtbox.Location = new System.Drawing.Point(177, 79);
            this.pctxtbox.Multiline = true;
            this.pctxtbox.Name = "pctxtbox";
            this.pctxtbox.Size = new System.Drawing.Size(264, 22);
            this.pctxtbox.TabIndex = 23;
            // 
            // phctxtbox
            // 
            this.phctxtbox.Location = new System.Drawing.Point(195, 51);
            this.phctxtbox.Multiline = true;
            this.phctxtbox.Name = "phctxtbox";
            this.phctxtbox.Size = new System.Drawing.Size(245, 22);
            this.phctxtbox.TabIndex = 22;
            // 
            // sssctxtbox
            // 
            this.sssctxtbox.Location = new System.Drawing.Point(157, 24);
            this.sssctxtbox.Multiline = true;
            this.sssctxtbox.Name = "sssctxtbox";
            this.sssctxtbox.Size = new System.Drawing.Size(284, 22);
            this.sssctxtbox.TabIndex = 21;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(41, 107);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(33, 16);
            this.label25.TabIndex = 19;
            this.label25.Text = "Tax:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(41, 82);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(130, 16);
            this.label24.TabIndex = 18;
            this.label24.Text = "Pagibig Contribution:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(41, 54);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(148, 16);
            this.label23.TabIndex = 17;
            this.label23.Text = "Phil-Health Contribution:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(41, 27);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(110, 16);
            this.label22.TabIndex = 16;
            this.label22.Text = "SSS Contribution:";
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox7.Controls.Add(this.octxtbox);
            this.groupBox7.Controls.Add(this.otxtbox);
            this.groupBox7.Controls.Add(this.sltxtbox);
            this.groupBox7.Controls.Add(this.fsltxtbox);
            this.groupBox7.Controls.Add(this.fsdtxtbox);
            this.groupBox7.Controls.Add(this.piltxtbox);
            this.groupBox7.Controls.Add(this.sssltxtbox);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.label26);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(460, 344);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(446, 227);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "OTHER DEDUCTIONS";
            // 
            // octxtbox
            // 
            this.octxtbox.FormattingEnabled = true;
            this.octxtbox.Location = new System.Drawing.Point(129, 169);
            this.octxtbox.Name = "octxtbox";
            this.octxtbox.Size = new System.Drawing.Size(312, 24);
            this.octxtbox.TabIndex = 31;
            // 
            // otxtbox
            // 
            this.otxtbox.Location = new System.Drawing.Point(126, 199);
            this.otxtbox.Multiline = true;
            this.otxtbox.Name = "otxtbox";
            this.otxtbox.Size = new System.Drawing.Size(314, 22);
            this.otxtbox.TabIndex = 30;
            // 
            // sltxtbox
            // 
            this.sltxtbox.Location = new System.Drawing.Point(129, 143);
            this.sltxtbox.Multiline = true;
            this.sltxtbox.Name = "sltxtbox";
            this.sltxtbox.Size = new System.Drawing.Size(311, 22);
            this.sltxtbox.TabIndex = 29;
            // 
            // fsltxtbox
            // 
            this.fsltxtbox.Location = new System.Drawing.Point(185, 114);
            this.fsltxtbox.Multiline = true;
            this.fsltxtbox.Name = "fsltxtbox";
            this.fsltxtbox.Size = new System.Drawing.Size(255, 22);
            this.fsltxtbox.TabIndex = 28;
            // 
            // fsdtxtbox
            // 
            this.fsdtxtbox.Location = new System.Drawing.Point(202, 84);
            this.fsdtxtbox.Multiline = true;
            this.fsdtxtbox.Name = "fsdtxtbox";
            this.fsdtxtbox.Size = new System.Drawing.Size(238, 22);
            this.fsdtxtbox.TabIndex = 27;
            // 
            // piltxtbox
            // 
            this.piltxtbox.Location = new System.Drawing.Point(143, 54);
            this.piltxtbox.Multiline = true;
            this.piltxtbox.Name = "piltxtbox";
            this.piltxtbox.Size = new System.Drawing.Size(297, 22);
            this.piltxtbox.TabIndex = 26;
            // 
            // sssltxtbox
            // 
            this.sssltxtbox.Location = new System.Drawing.Point(126, 27);
            this.sssltxtbox.Multiline = true;
            this.sssltxtbox.Name = "sssltxtbox";
            this.sssltxtbox.Size = new System.Drawing.Size(314, 22);
            this.sssltxtbox.TabIndex = 21;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(41, 180);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(49, 16);
            this.label31.TabIndex = 25;
            this.label31.Text = "Others:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(41, 146);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(82, 16);
            this.label30.TabIndex = 24;
            this.label30.Text = "Salary Loan:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(41, 117);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(138, 16);
            this.label29.TabIndex = 23;
            this.label29.Text = "Faculty Savings Loan:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(41, 87);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(155, 16);
            this.label28.TabIndex = 22;
            this.label28.Text = "Faculty Savings Deposit:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(41, 57);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(96, 16);
            this.label27.TabIndex = 21;
            this.label27.Text = "PAGIBIG Loan:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(41, 30);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(70, 16);
            this.label26.TabIndex = 20;
            this.label26.Text = "SSS Loan:";
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox8.Controls.Add(this.tdtxtbox);
            this.groupBox8.Controls.Add(this.label32);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(460, 577);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(446, 96);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "DEDUCTION SUMMARY";
            // 
            // tdtxtbox
            // 
            this.tdtxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tdtxtbox.Location = new System.Drawing.Point(159, 36);
            this.tdtxtbox.Multiline = true;
            this.tdtxtbox.Name = "tdtxtbox";
            this.tdtxtbox.Size = new System.Drawing.Size(281, 52);
            this.tdtxtbox.TabIndex = 21;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(41, 49);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(112, 16);
            this.label32.TabIndex = 26;
            this.label32.Text = "Total Deductions:";
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox9.Controls.Add(this.listBox1);
            this.groupBox9.Location = new System.Drawing.Point(912, 13);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(455, 698);
            this.groupBox9.TabIndex = 5;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "PAYSLIP VIEW DETAILS";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(6, 32);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(443, 660);
            this.listBox1.TabIndex = 0;
            // 
            // browsetxtbox
            // 
            this.browsetxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.browsetxtbox.BackColor = System.Drawing.Color.Maroon;
            this.browsetxtbox.Location = new System.Drawing.Point(733, 169);
            this.browsetxtbox.Name = "browsetxtbox";
            this.browsetxtbox.Size = new System.Drawing.Size(85, 32);
            this.browsetxtbox.TabIndex = 6;
            this.browsetxtbox.Text = "BROWSE";
            this.browsetxtbox.UseVisualStyleBackColor = false;
            this.browsetxtbox.Click += new System.EventHandler(this.Browsetxtbox_Click);
            // 
            // calctxtbox
            // 
            this.calctxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.calctxtbox.BackColor = System.Drawing.Color.Maroon;
            this.calctxtbox.Location = new System.Drawing.Point(8, 679);
            this.calctxtbox.Name = "calctxtbox";
            this.calctxtbox.Size = new System.Drawing.Size(129, 32);
            this.calctxtbox.TabIndex = 7;
            this.calctxtbox.Text = "CALCULATE";
            this.calctxtbox.UseVisualStyleBackColor = false;
            this.calctxtbox.Click += new System.EventHandler(this.Calctxtbox_Click);
            // 
            // newtxtbox
            // 
            this.newtxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.newtxtbox.BackColor = System.Drawing.Color.Maroon;
            this.newtxtbox.Location = new System.Drawing.Point(143, 679);
            this.newtxtbox.Name = "newtxtbox";
            this.newtxtbox.Size = new System.Drawing.Size(117, 32);
            this.newtxtbox.TabIndex = 8;
            this.newtxtbox.Text = "NEW";
            this.newtxtbox.UseVisualStyleBackColor = false;
            this.newtxtbox.Click += new System.EventHandler(this.Newtxtbox_Click);
            // 
            // canceltxtbox
            // 
            this.canceltxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.canceltxtbox.BackColor = System.Drawing.Color.Maroon;
            this.canceltxtbox.Location = new System.Drawing.Point(266, 679);
            this.canceltxtbox.Name = "canceltxtbox";
            this.canceltxtbox.Size = new System.Drawing.Size(97, 32);
            this.canceltxtbox.TabIndex = 9;
            this.canceltxtbox.Text = "CANCEL";
            this.canceltxtbox.UseVisualStyleBackColor = false;
            // 
            // printtxtbox
            // 
            this.printtxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.printtxtbox.BackColor = System.Drawing.Color.Maroon;
            this.printtxtbox.Location = new System.Drawing.Point(369, 679);
            this.printtxtbox.Name = "printtxtbox";
            this.printtxtbox.Size = new System.Drawing.Size(175, 32);
            this.printtxtbox.TabIndex = 10;
            this.printtxtbox.Text = "PRINT PAYSLIP";
            this.printtxtbox.UseVisualStyleBackColor = false;
            this.printtxtbox.Click += new System.EventHandler(this.Printtxtbox_Click);
            // 
            // previewtxtbox
            // 
            this.previewtxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.previewtxtbox.BackColor = System.Drawing.Color.Maroon;
            this.previewtxtbox.Location = new System.Drawing.Point(550, 679);
            this.previewtxtbox.Name = "previewtxtbox";
            this.previewtxtbox.Size = new System.Drawing.Size(258, 32);
            this.previewtxtbox.TabIndex = 11;
            this.previewtxtbox.Text = "PREVIEW PAYMENT DETAIL";
            this.previewtxtbox.UseVisualStyleBackColor = false;
            this.previewtxtbox.Click += new System.EventHandler(this.Previewtxtbox_Click);
            // 
            // exittxtbox
            // 
            this.exittxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.exittxtbox.BackColor = System.Drawing.Color.Maroon;
            this.exittxtbox.Location = new System.Drawing.Point(814, 679);
            this.exittxtbox.Name = "exittxtbox";
            this.exittxtbox.Size = new System.Drawing.Size(92, 32);
            this.exittxtbox.TabIndex = 12;
            this.exittxtbox.Text = "EXIT";
            this.exittxtbox.UseVisualStyleBackColor = false;
            this.exittxtbox.Click += new System.EventHandler(this.Exittxtbox_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(674, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(208, 143);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.PictureBox1_Click);
            // 
            // Example5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1373, 718);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.exittxtbox);
            this.Controls.Add(this.previewtxtbox);
            this.Controls.Add(this.printtxtbox);
            this.Controls.Add(this.canceltxtbox);
            this.Controls.Add(this.newtxtbox);
            this.Controls.Add(this.calctxtbox);
            this.Controls.Add(this.browsetxtbox);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Example5";
            this.Text = "Example5";
            this.Load += new System.EventHandler(this.Example5_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox employeetxtbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox dtxtbox;
        private System.Windows.Forms.TextBox cstxtbox;
        private System.Windows.Forms.TextBox snametxtbox;
        private System.Windows.Forms.TextBox mnametxtbox;
        private System.Windows.Forms.TextBox fnametxtbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox deptxtbox;
        private System.Windows.Forms.TextBox estxtbox;
        private System.Windows.Forms.TextBox nodtxtbox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox ipco1txtbox;
        private System.Windows.Forms.TextBox nhco1txtbox;
        private System.Windows.Forms.TextBox rate1txtbox;
        private System.Windows.Forms.TextBox thptxtbox;
        private System.Windows.Forms.TextBox nhco2txtbox;
        private System.Windows.Forms.TextBox rate2txtbox;
        private System.Windows.Forms.TextBox toiptxtbox;
        private System.Windows.Forms.TextBox nhco3txtbox;
        private System.Windows.Forms.TextBox rate3txtbox;
        private System.Windows.Forms.TextBox nitxtbox;
        private System.Windows.Forms.TextBox gitxtbox;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox ttxtbox;
        private System.Windows.Forms.TextBox pctxtbox;
        private System.Windows.Forms.TextBox phctxtbox;
        private System.Windows.Forms.TextBox sssctxtbox;
        private System.Windows.Forms.TextBox sltxtbox;
        private System.Windows.Forms.TextBox fsltxtbox;
        private System.Windows.Forms.TextBox fsdtxtbox;
        private System.Windows.Forms.TextBox piltxtbox;
        private System.Windows.Forms.TextBox sssltxtbox;
        private System.Windows.Forms.TextBox tdtxtbox;
        private System.Windows.Forms.Button browsetxtbox;
        private System.Windows.Forms.Button calctxtbox;
        private System.Windows.Forms.Button newtxtbox;
        private System.Windows.Forms.Button canceltxtbox;
        private System.Windows.Forms.Button printtxtbox;
        private System.Windows.Forms.Button previewtxtbox;
        private System.Windows.Forms.Button exittxtbox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox octxtbox;
        private System.Windows.Forms.TextBox otxtbox;
        public System.Windows.Forms.ListBox listBox1;
    }
}