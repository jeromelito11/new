﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RODRIGUEZ_LESSON1
{
    public partial class L2LA : Form
    {
        
        public L2LA()
        {
            InitializeComponent();
        }
       
        private void L2LA_Load(object sender, EventArgs e)
        {
            // Programs
            comboBox1.Items.Add("Aeronautical Engineering");
            comboBox1.Items.Add("Civil Engineering");
            comboBox1.Items.Add("Computer Engineering");
            comboBox1.Items.Add("Electronics Engineering");
            comboBox1.Items.Add("Electrical Engineering");
            comboBox1.Items.Add("Industrial Engineering");
            comboBox1.Items.Add("Mechanical Engineering");

            // Disalbling textboxes
            ttftxtbox2.Enabled = false;
            tmftxtbox2.Enabled = false;
            tnutxtbox2.Enabled = false;
            ttaftxtbox2.Enabled = false;

            this.WindowState = FormWindowState.Maximized;

        }

        private void ListBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image|*.png;*.jpg;*.jpeg;*.bmp;*.gif";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image = Image.FromFile(@openFileDialog.FileName);

                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                }
            }
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Clering text data
            SNtxtBox.Clear();
            comboBox1.ResetText();
            Snumtxtbox.Clear();
            yltxtbox.Clear();
            dtp.ResetText();
            S.Clear();
            cnumtxtbox.Clear();
            ccodetxtbox.Clear();
            cdesctxtbox.Clear();
            ultxtbox.Clear();
            ulabtxtbox.Clear();
            ttxtbox.Clear();
            dtxtbox.Clear();
            cutxtbox.Clear();
            tnutxtbox.Clear();
            lftxtbox.Clear();
            ttftxtbox.Clear();
            tmftxtbox.Clear();
            clftxtbox.Clear();
            ebftxtbox.Clear();
            ttaftxtbox.Clear();
            comlbtxtbox.Clear();
            clftxtbox2.Clear();
            ebtxtbox.Clear();
            tosftxtbox.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Submit to listbox
            listBox1.Items.Insert(0, cnumtxtbox.Text);
            listBox2.Items.Insert(0, ccodetxtbox.Text);
            listBox3.Items.Insert(0, cdesctxtbox.Text);
            listBox4.Items.Insert(0, ultxtbox.Text);
            listBox5.Items.Insert(0, ulabtxtbox.Text);
            listBox6.Items.Insert(0, cutxtbox.Text);
            listBox7.Items.Insert(0, ttxtbox.Text);
            listBox8.Items.Insert(0, dtxtbox.Text);

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }
        private double ttlnumunits = 0;
        private double totalmiscfee = 0;
        private double ttllabfee = 0;
        private double ttlcisfee = 0;
        private double ttlexbfee = 0;
        private void button4_Click(object sender, EventArgs e)
        {
            // Calculate Button
            double total_units, total_tuition_fee, total_tuitionandfee;

            total_units = Convert.ToDouble(ultxtbox.Text) + Convert.ToDouble(ulabtxtbox.Text);
            cutxtbox.Text = Convert.ToString(total_units);

            ttlnumunits += total_units;

            total_tuition_fee = ttlnumunits * 1500;

            totalmiscfee += Convert.ToDouble(lftxtbox.Text) + Convert.ToDouble(clftxtbox.Text) + 
                Convert.ToDouble(ebftxtbox.Text);

            total_tuitionandfee = totalmiscfee + total_tuition_fee;
            //BOTTOM MISC FEES
            ttllabfee += Convert.ToDouble(lftxtbox.Text);
            comlbtxtbox.Text = Convert.ToString(ttllabfee);
            ttlcisfee += Convert.ToDouble(clftxtbox.Text);
            clftxtbox2.Text = Convert.ToString(ttlcisfee);
            ttlexbfee += Convert.ToDouble(ebftxtbox.Text);
            ebtxtbox.Text = Convert.ToString(ttlexbfee);
            tosftxtbox.Text = Convert.ToString(ttlexbfee + ttlcisfee + ttlexbfee);
            // Commit testing
            tnutxtbox.Text = Convert.ToString(ttlnumunits);
            ttftxtbox.Text = Convert.ToString(total_tuition_fee);
            tmftxtbox.Text = Convert.ToString(totalmiscfee);
            ttaftxtbox.Text = Convert.ToString(total_tuitionandfee);

            ttftxtbox2.Text = Convert.ToString(total_tuition_fee);
            tnutxtbox2.Text = Convert.ToString(ttlnumunits);
            tmftxtbox2.Text = Convert.ToString(totalmiscfee);
            ttaftxtbox2.Text = Convert.ToString(total_tuitionandfee);
        }

        private void tmftxtbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
