﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace RODRIGUEZ_LESSON1
{
    public partial class Example5 : Form
    {

        private Double basic_netincome = 0.00, basic_numhrs = 0.00, basic_rate = 0.00,
            hono_netincome = 0.00, hono_numhrs = 0.00, hono_rate = 0.00, other_netincome = 0.00,
            other_numhrs = 0.00, other_rate = 0.00;
        private Double netincome = 0.00, grossincome = 0.00, sss_contrib = 0.00,
            pagibig_contrib = 0.00, philhealth_contrib = 0.00, tax_contrib = 0.00;
        private Double sss_loan = 0.00, pagibig_loan = 0.00, salary_loan = 0.00,
            salary_savings = 0.00, faculty_sav_loan = 0.00, other_deduction = 0.00,
            total_deduction = 0.00, total_contrib = 0.00, total_loan = 0.00;

        private void GroupBox2_Enter(object sender, EventArgs e)
        {

        }

        

        private void Browsetxtbox_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image|*.png;*.jpg;*.jpeg;*.bmp;*.gif";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image = Image.FromFile(@openFileDialog.FileName);

                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                }
            }
        }

        private void Exittxtbox_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Nhco2txtbox_TextChanged(object sender, EventArgs e)
        {
            hono_numhrs = Convert.ToDouble(nhco2txtbox.Text);
            hono_rate = Convert.ToDouble(rate2txtbox.Text);
            hono_netincome = hono_numhrs * hono_rate;
            thptxtbox.Text = hono_netincome.ToString("n");
        }

        private void Nhco1txtbox_TextChanged(object sender, EventArgs e)
        {
            basic_numhrs = Convert.ToDouble(nhco1txtbox.Text);
            basic_rate = Convert.ToDouble(rate1txtbox.Text);
            basic_netincome = basic_numhrs * basic_rate;
            ipco1txtbox.Text = basic_netincome.ToString("n");
        }

        private void Calctxtbox_Click(object sender, EventArgs e)
        {
            sss_contrib = Convert.ToDouble(sssctxtbox.Text);
            pagibig_contrib = Convert.ToDouble(pctxtbox.Text);
            philhealth_contrib = Convert.ToDouble(phctxtbox.Text);
            tax_contrib = Convert.ToDouble(ttxtbox.Text);
            sss_loan = Convert.ToDouble(sssltxtbox.Text);
            pagibig_loan = Convert.ToDouble(piltxtbox.Text);
            salary_loan = Convert.ToDouble(sltxtbox.Text);
            other_deduction = Convert.ToDouble(octxtbox.Text);
            
            total_contrib = sss_contrib + pagibig_contrib + philhealth_contrib + tax_contrib;
            total_loan = sss_loan + pagibig_loan + salary_loan + faculty_sav_loan + salary_savings + other_deduction;
            total_deduction = total_contrib + total_loan;
            
            tdtxtbox.Text = total_deduction.ToString("n");
            netincome = grossincome - total_deduction;
            nitxtbox.Text = netincome.ToString("n");
        }

        private void Example5_Load(object sender, EventArgs e)
        {
            rate1txtbox.Text = "0.00";
            rate2txtbox.Text = "0.00";
            rate3txtbox.Text = "0.00";
            nhco1txtbox.Text = "0.00";
            nhco2txtbox.Text = "0.00";
            nhco3txtbox.Text = "0.00";
            ipco1txtbox.Enabled = false;
            thptxtbox.Enabled = false;
            toiptxtbox.Enabled = false;
            nitxtbox.Enabled = false;
            gitxtbox.Enabled = false;
            tdtxtbox.Enabled = false;
            sssctxtbox.Text = "0.00";
            pctxtbox.Text = "0.00";
            phctxtbox.Text = "0.00";
            ttxtbox.Text = "0.00";
            sssltxtbox.Text = "0.00";
            piltxtbox.Text = "0.00";
            fsdtxtbox.Text = "0.00";
            fsltxtbox.Text = "0.00";
            sltxtbox.Text = "0.00";
            otxtbox.Text = "0.00";
            octxtbox.Text = "Select Other Deduction";
            octxtbox.Items.Add("Other 1");
            octxtbox.Items.Add("Other 2");
            octxtbox.Items.Add("Other 3");
            octxtbox.Items.Add("Other 4");

            this.WindowState = FormWindowState.Maximized;
        }

        private void Newtxtbox_Click(object sender, EventArgs e)
        {
            employeetxtbox.Clear();
            fnametxtbox.Clear();
            mnametxtbox.Clear();
            snametxtbox.Clear();
            cstxtbox.Clear();
            dtxtbox.Clear();
            nodtxtbox.Clear();
            estxtbox.Clear();
            deptxtbox.Clear();
            ipco1txtbox.Clear();
            thptxtbox.Clear();
            nitxtbox.Clear();
            gitxtbox.Clear();
            sssctxtbox.Clear();
            pctxtbox.Clear();
            phctxtbox.Clear();
            ttxtbox.Clear();
            sssltxtbox.Clear();
            piltxtbox.Clear();
            rate1txtbox.Text = "0.00";
            rate2txtbox.Text = "0.00";
            rate3txtbox.Text = "0.00";
            nhco1txtbox.Text = "0.00";
            nhco2txtbox.Text = "0.00";
            nhco3txtbox.Text = "0.00";
        }

        private void Printtxtbox_Click(object sender, EventArgs e)
        {
            Example5_PrintFrm print = new Example5_PrintFrm();
            print.listBox2.Items.AddRange(this.listBox1.Items);
            print.Show();
        }

     
        private void Previewtxtbox_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("Employee Number: " + "" + employeetxtbox.Text);
            listBox1.Items.Add("Firstname: " + "" + fnametxtbox.Text);
            listBox1.Items.Add("Middlename: " + "" + mnametxtbox.Text);
            listBox1.Items.Add("Surname: " + "" + snametxtbox.Text);
            listBox1.Items.Add("Designation: " + "" + dtxtbox.Text);
            listBox1.Items.Add("Employee Status:" + "" + estxtbox.Text);
            listBox1.Items.Add("Department: " + "" + deptxtbox.Text);
            listBox1.Items.Add("Pay Date: " + "" + dateTimePicker1.Text);
            listBox1.Items.Add("-----------------------------------------");
            listBox1.Items.Add("BP Num. of Hrs.: " + "" + nhco1txtbox.Text);
            listBox1.Items.Add("BP Rate/Hr: " + "" + rate1txtbox.Text);
            listBox1.Items.Add("Basic Pay Income: " + "" + ipco1txtbox.Text);
            listBox1.Items.Add("");
            listBox1.Items.Add("HI Num. of Hrs.: " + "" + nhco2txtbox.Text);
            listBox1.Items.Add("HI Rate/Hr: " + "" + rate2txtbox.Text);
            listBox1.Items.Add("Honorarium Income: " + "" + thptxtbox.Text);
            listBox1.Items.Add("");
            listBox1.Items.Add("OTI Num. of Hrs.: " + "" + nhco3txtbox.Text);
            listBox1.Items.Add("OTI Rate/Hr: " + "" + rate3txtbox.Text);
            listBox1.Items.Add("Other Income: " + "" + toiptxtbox.Text);
            listBox1.Items.Add("-----------------------------------------");
            listBox1.Items.Add("SSS Contribution: " + "" + sssctxtbox.Text);
            listBox1.Items.Add("PhilHealth Contribution: " + "" + phctxtbox.Text);
            listBox1.Items.Add("Tax Contribution: " + "" + ttxtbox.Text);
            listBox1.Items.Add("SSS Loan:" + "" + sssltxtbox.Text);
            listBox1.Items.Add("Pagibig Loan: " + "" + piltxtbox.Text);
            listBox1.Items.Add("Faculty Savings Deposit: " + "" + fsdtxtbox.Text);
            listBox1.Items.Add("Faculty Savings Loan: " + "" + fsltxtbox.Text);
            listBox1.Items.Add("Salary Loan: " + "" + sltxtbox.Text);
            listBox1.Items.Add("Other Loan: " + "" + octxtbox.Text);
            listBox1.Items.Add("-----------------------------------------");
            listBox1.Items.Add("Total Deduction: " + "" + tdtxtbox.Text);
            listBox1.Items.Add("Gross Income: " + "" + gitxtbox.Text);
            listBox1.Items.Add("Net Income: " + "" + nitxtbox.Text);
        }

        

        private void Nhco3txtbox_TextChanged(object sender, EventArgs e)
        {
            other_numhrs = Convert.ToDouble(nhco3txtbox.Text);
            other_rate = Convert.ToDouble(rate3txtbox.Text);
            other_netincome = other_numhrs * other_rate;
            toiptxtbox.Text = other_netincome.ToString("n");
            grossincome = basic_netincome + hono_netincome + other_netincome;
            gitxtbox.Text = grossincome.ToString();
        }

        
        public Example5()
        {
            InitializeComponent();
        }
        
        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
