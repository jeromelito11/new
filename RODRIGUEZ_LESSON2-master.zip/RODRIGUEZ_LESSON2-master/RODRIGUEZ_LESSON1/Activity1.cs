﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RODRIGUEZ_LESSON1
{
    public partial class Activity1 : Form
    {
        private double amount_paid, price, cash_given, change;
        private int quantity;
        public Activity1()
        {
            InitializeComponent();
        }

        private void Activity1_Load(object sender, EventArgs e)
        {
            textBox4.Enabled = false;
            this.Location = new Point(0, 0);
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.WindowState = FormWindowState.Maximized;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            //code for inserting or assigning a value to the text property of a textbox
            itemboxTxtbox.Text = "Cornsilog";
            priceTxtbox.Text = "99";
            textBox1.Focus();
        }
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            //code for inserting or assigning a value to the text property of a textbox
            itemboxTxtbox.Text = "Tapsilog";
            priceTxtbox.Text = "99";
            textBox1.Focus();
            textBox1.Clear();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            //code for inserting or assigning a value to the text property of a textbox
            itemboxTxtbox.Text = "Tocilog";
            priceTxtbox.Text = "99";
            textBox1.Focus();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            //code for inserting or assigning a value to the text property of a textbox
            itemboxTxtbox.Text = "Hamsilog";
            priceTxtbox.Text = "99";
            textBox1.Focus();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            //code for inserting or assigning a value to the text property of a textbox
            itemboxTxtbox.Text = "Chicksilog";
            priceTxtbox.Text = "110";
            textBox1.Focus();
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            //code for inserting or assigning a value to the text property of a textbox
            itemboxTxtbox.Text = "Porksilog";
            priceTxtbox.Text = "110";
            textBox1.Focus();
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            //code for inserting or assigning a value to the text property of a textbox
            itemboxTxtbox.Text = "Sisigsilog";
            priceTxtbox.Text = "120";
            textBox1.Focus();
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            //code for inserting or assigning a value to the text property of a textbox
            itemboxTxtbox.Text = "Spamsilog";
            priceTxtbox.Text = "120";
            textBox1.Focus();
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            //code for inserting or assigning a value to the text property of a textbox
            itemboxTxtbox.Text = "Lechon Kawali Silog";
            priceTxtbox.Text = "150";
            textBox1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // code for calculate button
            try
            {
                amount_paid = Convert.ToDouble(textBox2.Text);
                cash_given = Convert.ToDouble(textBox3.Text);
                change = cash_given - amount_paid;
                textBox4.Text = change.ToString("C");
                textBox2.Text = amount_paid.ToString("C");
                textBox3.Text = cash_given.ToString("C");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                textBox3.Clear();
                textBox3.Focus();
            }
            finally
            {
                MessageBox.Show("Successfully Computed");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try 
            { 
                price = Convert.ToDouble(priceTxtbox.Text);
                quantity = Convert.ToInt32(textBox1.Text);
                amount_paid = price * quantity;
                textBox2.Text = amount_paid.ToString("n");
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid Data Input");
                textBox1.Clear();
                textBox1.Focus();
            }
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            //code for inserting or assigning a value to the text property of a textbox
            itemboxTxtbox.Text = "Bangsilog";
            priceTxtbox.Text = "120";
            textBox1.Focus();
        }

        private void exiBtn_Click(object sender, EventArgs e)
        {
            //code for clearing oor emptying the value of the text property of a textbox
            itemboxTxtbox.Clear();
            priceTxtbox.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }

        private void newBtn_Click(object sender, EventArgs e)
        {
            //code for closing the executionof the Windows Form Application
            this.Close();

        }
    }
}
