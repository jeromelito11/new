﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RODRIGUEZ_LESSON1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void jeePOSINCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Activity2 newMDIChild = new Activity2();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Activity3 newMDIChild = new Activity3();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void simplePOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Activity1 newMDIChild = new Activity1();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cVR7POSIncToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Admin_Inc newMDIChild = new Admin_Inc();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void cVR7POSOrderingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Admin_Order newMDIChild = new Admin_Order();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void tileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void tileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void cascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void payrollApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Activity5 newMDIChild = new Activity5();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void employeeRegistrationPageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Example5 newMDIChild = new Example5();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void userAccountPageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            L2LA newMDIChild = new L2LA();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }
    }
}
