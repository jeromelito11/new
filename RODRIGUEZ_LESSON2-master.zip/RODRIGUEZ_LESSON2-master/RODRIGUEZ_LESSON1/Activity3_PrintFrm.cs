﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RODRIGUEZ_LESSON1
{
    public partial class Activity3_PrintFrm : Form
    {
        public Activity3_PrintFrm()
        {
            InitializeComponent();
            listBox10.Items.AddRange(listBox10.Items);
        }

        private void Activity3_PrintFrm_Load(object sender, EventArgs e)
        {

        }
    }
}
