﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RODRIGUEZ_LESSON1
{
    public partial class Admin_Inc : Form
    {
        public Admin_Inc()
        {
            InitializeComponent();
        }

        private void Admin_Inc_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }
    }
}
