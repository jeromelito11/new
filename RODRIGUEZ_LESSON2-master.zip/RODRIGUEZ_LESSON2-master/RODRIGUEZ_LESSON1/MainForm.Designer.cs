﻿namespace RODRIGUEZ_LESSON1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.pOSCashierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jeePOSINCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.simplePOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pOSAdministratorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cVR7POSIncToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cVR7POSOrderingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userAccountPageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.payrollToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.payrollApplicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeRegistrationPageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.payrollReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.windowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileVerticalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileHorizontalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cascadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pOSCashierToolStripMenuItem,
            this.pOSAdministratorToolStripMenuItem,
            this.userAccountToolStripMenuItem,
            this.payrollToolStripMenuItem,
            this.employeeInformationToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.windowToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1325, 30);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // pOSCashierToolStripMenuItem
            // 
            this.pOSCashierToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jeePOSINCToolStripMenuItem,
            this.toolStripMenuItem2,
            this.simplePOSToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.pOSCashierToolStripMenuItem.Name = "pOSCashierToolStripMenuItem";
            this.pOSCashierToolStripMenuItem.Size = new System.Drawing.Size(102, 26);
            this.pOSCashierToolStripMenuItem.Text = "POS Cashier";
            // 
            // jeePOSINCToolStripMenuItem
            // 
            this.jeePOSINCToolStripMenuItem.Name = "jeePOSINCToolStripMenuItem";
            this.jeePOSINCToolStripMenuItem.Size = new System.Drawing.Size(221, 26);
            this.jeePOSINCToolStripMenuItem.Text = "CVR7 POS Inc.";
            this.jeePOSINCToolStripMenuItem.Click += new System.EventHandler(this.jeePOSINCToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(221, 26);
            this.toolStripMenuItem2.Text = "CVR7 POS Ordering";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // simplePOSToolStripMenuItem
            // 
            this.simplePOSToolStripMenuItem.Name = "simplePOSToolStripMenuItem";
            this.simplePOSToolStripMenuItem.Size = new System.Drawing.Size(221, 26);
            this.simplePOSToolStripMenuItem.Text = "Simple POS";
            this.simplePOSToolStripMenuItem.Click += new System.EventHandler(this.simplePOSToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(221, 26);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // pOSAdministratorToolStripMenuItem
            // 
            this.pOSAdministratorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cVR7POSIncToolStripMenuItem,
            this.cVR7POSOrderingToolStripMenuItem});
            this.pOSAdministratorToolStripMenuItem.Name = "pOSAdministratorToolStripMenuItem";
            this.pOSAdministratorToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.pOSAdministratorToolStripMenuItem.Text = "POS Administrator";
            // 
            // cVR7POSIncToolStripMenuItem
            // 
            this.cVR7POSIncToolStripMenuItem.Name = "cVR7POSIncToolStripMenuItem";
            this.cVR7POSIncToolStripMenuItem.Size = new System.Drawing.Size(221, 26);
            this.cVR7POSIncToolStripMenuItem.Text = "CVR7 POS Inc.";
            this.cVR7POSIncToolStripMenuItem.Click += new System.EventHandler(this.cVR7POSIncToolStripMenuItem_Click);
            // 
            // cVR7POSOrderingToolStripMenuItem
            // 
            this.cVR7POSOrderingToolStripMenuItem.Name = "cVR7POSOrderingToolStripMenuItem";
            this.cVR7POSOrderingToolStripMenuItem.Size = new System.Drawing.Size(221, 26);
            this.cVR7POSOrderingToolStripMenuItem.Text = "CVR7 POS Ordering";
            this.cVR7POSOrderingToolStripMenuItem.Click += new System.EventHandler(this.cVR7POSOrderingToolStripMenuItem_Click);
            // 
            // userAccountToolStripMenuItem
            // 
            this.userAccountToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userAccountPageToolStripMenuItem});
            this.userAccountToolStripMenuItem.Name = "userAccountToolStripMenuItem";
            this.userAccountToolStripMenuItem.Size = new System.Drawing.Size(110, 26);
            this.userAccountToolStripMenuItem.Text = "User Account";
            // 
            // userAccountPageToolStripMenuItem
            // 
            this.userAccountPageToolStripMenuItem.Name = "userAccountPageToolStripMenuItem";
            this.userAccountPageToolStripMenuItem.Size = new System.Drawing.Size(215, 26);
            this.userAccountPageToolStripMenuItem.Text = "User Account Page";
            this.userAccountPageToolStripMenuItem.Click += new System.EventHandler(this.userAccountPageToolStripMenuItem_Click);
            // 
            // payrollToolStripMenuItem
            // 
            this.payrollToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.payrollApplicationToolStripMenuItem});
            this.payrollToolStripMenuItem.Name = "payrollToolStripMenuItem";
            this.payrollToolStripMenuItem.Size = new System.Drawing.Size(67, 26);
            this.payrollToolStripMenuItem.Text = "Payroll";
            // 
            // payrollApplicationToolStripMenuItem
            // 
            this.payrollApplicationToolStripMenuItem.Name = "payrollApplicationToolStripMenuItem";
            this.payrollApplicationToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.payrollApplicationToolStripMenuItem.Text = "Payroll Application";
            this.payrollApplicationToolStripMenuItem.Click += new System.EventHandler(this.payrollApplicationToolStripMenuItem_Click);
            // 
            // employeeInformationToolStripMenuItem
            // 
            this.employeeInformationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeeRegistrationPageToolStripMenuItem});
            this.employeeInformationToolStripMenuItem.Name = "employeeInformationToolStripMenuItem";
            this.employeeInformationToolStripMenuItem.Size = new System.Drawing.Size(171, 26);
            this.employeeInformationToolStripMenuItem.Text = "Employee Information";
            // 
            // employeeRegistrationPageToolStripMenuItem
            // 
            this.employeeRegistrationPageToolStripMenuItem.Name = "employeeRegistrationPageToolStripMenuItem";
            this.employeeRegistrationPageToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.employeeRegistrationPageToolStripMenuItem.Text = "Employee Registration Page";
            this.employeeRegistrationPageToolStripMenuItem.Click += new System.EventHandler(this.employeeRegistrationPageToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salesReportsToolStripMenuItem,
            this.productReportsToolStripMenuItem,
            this.employeeReportsToolStripMenuItem,
            this.payrollReportsToolStripMenuItem,
            this.userReportsToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(74, 26);
            this.reportsToolStripMenuItem.Text = "Reports";
            this.reportsToolStripMenuItem.Click += new System.EventHandler(this.reportsToolStripMenuItem_Click);
            // 
            // salesReportsToolStripMenuItem
            // 
            this.salesReportsToolStripMenuItem.Name = "salesReportsToolStripMenuItem";
            this.salesReportsToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.salesReportsToolStripMenuItem.Text = "Sales Reports";
            // 
            // productReportsToolStripMenuItem
            // 
            this.productReportsToolStripMenuItem.Name = "productReportsToolStripMenuItem";
            this.productReportsToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.productReportsToolStripMenuItem.Text = "Product Reports";
            // 
            // employeeReportsToolStripMenuItem
            // 
            this.employeeReportsToolStripMenuItem.Name = "employeeReportsToolStripMenuItem";
            this.employeeReportsToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.employeeReportsToolStripMenuItem.Text = "Employee Reports";
            // 
            // payrollReportsToolStripMenuItem
            // 
            this.payrollReportsToolStripMenuItem.Name = "payrollReportsToolStripMenuItem";
            this.payrollReportsToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.payrollReportsToolStripMenuItem.Text = "Payroll Reports";
            // 
            // userReportsToolStripMenuItem
            // 
            this.userReportsToolStripMenuItem.Name = "userReportsToolStripMenuItem";
            this.userReportsToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.userReportsToolStripMenuItem.Text = "User Reports";
            // 
            // windowToolStripMenuItem
            // 
            this.windowToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tileVerticalToolStripMenuItem,
            this.tileHorizontalToolStripMenuItem,
            this.cascadeToolStripMenuItem});
            this.windowToolStripMenuItem.Name = "windowToolStripMenuItem";
            this.windowToolStripMenuItem.Size = new System.Drawing.Size(78, 26);
            this.windowToolStripMenuItem.Text = "Window";
            // 
            // tileVerticalToolStripMenuItem
            // 
            this.tileVerticalToolStripMenuItem.Name = "tileVerticalToolStripMenuItem";
            this.tileVerticalToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.tileVerticalToolStripMenuItem.Text = "Tile Vertical";
            this.tileVerticalToolStripMenuItem.Click += new System.EventHandler(this.tileVerticalToolStripMenuItem_Click);
            // 
            // tileHorizontalToolStripMenuItem
            // 
            this.tileHorizontalToolStripMenuItem.Name = "tileHorizontalToolStripMenuItem";
            this.tileHorizontalToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.tileHorizontalToolStripMenuItem.Text = "Tile Horizontal";
            this.tileHorizontalToolStripMenuItem.Click += new System.EventHandler(this.tileHorizontalToolStripMenuItem_Click);
            // 
            // cascadeToolStripMenuItem
            // 
            this.cascadeToolStripMenuItem.Name = "cascadeToolStripMenuItem";
            this.cascadeToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.cascadeToolStripMenuItem.Text = "Cascade";
            this.cascadeToolStripMenuItem.Click += new System.EventHandler(this.cascadeToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBox1,
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3});
            this.toolStrip1.Location = new System.Drawing.Point(0, 30);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1325, 31);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 31);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(29, 28);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(29, 28);
            this.toolStripButton2.Text = "toolStripButton2";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(29, 28);
            this.toolStripButton3.Text = "toolStripButton3";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1325, 670);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem pOSCashierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jeePOSINCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem pOSAdministratorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem payrollToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem windowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem simplePOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cVR7POSIncToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cVR7POSOrderingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userAccountPageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem payrollApplicationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeRegistrationPageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem payrollReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileVerticalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileHorizontalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cascadeToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
    }
}