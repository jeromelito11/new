﻿namespace RODRIGUEZ_LESSON1
{
    partial class Activity3_transfer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.BCMchkbox = new System.Windows.Forms.CheckBox();
            this.BMPchkbox = new System.Windows.Forms.CheckBox();
            this.BCornchkbox = new System.Windows.Forms.CheckBox();
            this.BChickenchkbox = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.AMPchkbox = new System.Windows.Forms.CheckBox();
            this.ACokechkbox = new System.Windows.Forms.CheckBox();
            this.ACornchkbox = new System.Windows.Forms.CheckBox();
            this.AChickenchkbox = new System.Windows.Forms.CheckBox();
            this.Aricechkbox = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.foodBRdbtn1 = new System.Windows.Forms.RadioButton();
            this.foodARdbtn1 = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.changetxtbox1 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.totalqtytxtbox1 = new System.Windows.Forms.TextBox();
            this.totalbillstxtbox1 = new System.Windows.Forms.TextBox();
            this.di1scountedamounttxtbox = new System.Windows.Forms.TextBox();
            this.di1scountamounttxtbox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.QtyTxtbox1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.price1tbox = new System.Windows.Forms.TextBox();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.BCMchkbox);
            this.groupBox3.Controls.Add(this.BMPchkbox);
            this.groupBox3.Controls.Add(this.BCornchkbox);
            this.groupBox3.Controls.Add(this.BChickenchkbox);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(304, 244);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 281);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Food Bundles B";
            // 
            // BCMchkbox
            // 
            this.BCMchkbox.AutoSize = true;
            this.BCMchkbox.Location = new System.Drawing.Point(24, 222);
            this.BCMchkbox.Name = "BCMchkbox";
            this.BCMchkbox.Size = new System.Drawing.Size(172, 20);
            this.BCMchkbox.TabIndex = 12;
            this.BCMchkbox.Text = "1 Tub Cream Mushroom";
            this.BCMchkbox.UseVisualStyleBackColor = true;
            // 
            // BMPchkbox
            // 
            this.BMPchkbox.AutoSize = true;
            this.BMPchkbox.Location = new System.Drawing.Point(24, 162);
            this.BMPchkbox.Name = "BMPchkbox";
            this.BMPchkbox.Size = new System.Drawing.Size(157, 20);
            this.BMPchkbox.TabIndex = 11;
            this.BMPchkbox.Text = "1 Tub Mashed Potato";
            this.BMPchkbox.UseVisualStyleBackColor = true;
            // 
            // BCornchkbox
            // 
            this.BCornchkbox.AutoSize = true;
            this.BCornchkbox.Location = new System.Drawing.Point(24, 99);
            this.BCornchkbox.Name = "BCornchkbox";
            this.BCornchkbox.Size = new System.Drawing.Size(94, 20);
            this.BCornchkbox.TabIndex = 10;
            this.BCornchkbox.Text = "1 Tub Corn";
            this.BCornchkbox.UseVisualStyleBackColor = true;
            // 
            // BChickenchkbox
            // 
            this.BChickenchkbox.AutoSize = true;
            this.BChickenchkbox.Location = new System.Drawing.Point(24, 44);
            this.BChickenchkbox.Name = "BChickenchkbox";
            this.BChickenchkbox.Size = new System.Drawing.Size(131, 20);
            this.BChickenchkbox.TabIndex = 9;
            this.BChickenchkbox.Text = "1 Bucket Chicken";
            this.BChickenchkbox.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 16);
            this.label4.TabIndex = 6;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.AMPchkbox);
            this.groupBox2.Controls.Add(this.ACokechkbox);
            this.groupBox2.Controls.Add(this.ACornchkbox);
            this.groupBox2.Controls.Add(this.AChickenchkbox);
            this.groupBox2.Controls.Add(this.Aricechkbox);
            this.groupBox2.Location = new System.Drawing.Point(304, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 226);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Food Bundles A";
            // 
            // AMPchkbox
            // 
            this.AMPchkbox.AutoSize = true;
            this.AMPchkbox.Location = new System.Drawing.Point(24, 187);
            this.AMPchkbox.Name = "AMPchkbox";
            this.AMPchkbox.Size = new System.Drawing.Size(130, 20);
            this.AMPchkbox.TabIndex = 8;
            this.AMPchkbox.Text = "2 Mashed Potato";
            this.AMPchkbox.UseVisualStyleBackColor = true;
            // 
            // ACokechkbox
            // 
            this.ACokechkbox.AutoSize = true;
            this.ACokechkbox.Location = new System.Drawing.Point(24, 68);
            this.ACokechkbox.Name = "ACokechkbox";
            this.ACokechkbox.Size = new System.Drawing.Size(71, 20);
            this.ACokechkbox.TabIndex = 7;
            this.ACokechkbox.Text = "4 Coke";
            this.ACokechkbox.UseVisualStyleBackColor = true;
            // 
            // ACornchkbox
            // 
            this.ACornchkbox.AutoSize = true;
            this.ACornchkbox.Location = new System.Drawing.Point(24, 149);
            this.ACornchkbox.Name = "ACornchkbox";
            this.ACornchkbox.Size = new System.Drawing.Size(67, 20);
            this.ACornchkbox.TabIndex = 7;
            this.ACornchkbox.Text = "4 Corn";
            this.ACornchkbox.UseVisualStyleBackColor = true;
            // 
            // AChickenchkbox
            // 
            this.AChickenchkbox.AutoSize = true;
            this.AChickenchkbox.Location = new System.Drawing.Point(24, 31);
            this.AChickenchkbox.Name = "AChickenchkbox";
            this.AChickenchkbox.Size = new System.Drawing.Size(131, 20);
            this.AChickenchkbox.TabIndex = 5;
            this.AChickenchkbox.Text = "1 Bucket Chicken";
            this.AChickenchkbox.UseVisualStyleBackColor = true;
            // 
            // Aricechkbox
            // 
            this.Aricechkbox.AutoSize = true;
            this.Aricechkbox.Location = new System.Drawing.Point(24, 109);
            this.Aricechkbox.Name = "Aricechkbox";
            this.Aricechkbox.Size = new System.Drawing.Size(67, 20);
            this.Aricechkbox.TabIndex = 5;
            this.Aricechkbox.Text = "4 Rice";
            this.Aricechkbox.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.foodBRdbtn1);
            this.groupBox1.Controls.Add(this.foodARdbtn1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(288, 114);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Food Order Choices";
            // 
            // foodBRdbtn1
            // 
            this.foodBRdbtn1.AutoSize = true;
            this.foodBRdbtn1.Location = new System.Drawing.Point(30, 68);
            this.foodBRdbtn1.Name = "foodBRdbtn1";
            this.foodBRdbtn1.Size = new System.Drawing.Size(117, 20);
            this.foodBRdbtn1.TabIndex = 1;
            this.foodBRdbtn1.TabStop = true;
            this.foodBRdbtn1.Text = "Food Bundle B";
            this.foodBRdbtn1.UseVisualStyleBackColor = true;
            // 
            // foodARdbtn1
            // 
            this.foodARdbtn1.AutoSize = true;
            this.foodARdbtn1.Location = new System.Drawing.Point(30, 31);
            this.foodARdbtn1.Name = "foodARdbtn1";
            this.foodARdbtn1.Size = new System.Drawing.Size(117, 20);
            this.foodARdbtn1.TabIndex = 0;
            this.foodARdbtn1.TabStop = true;
            this.foodARdbtn1.Text = "Food Bundle A";
            this.foodARdbtn1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.changetxtbox1);
            this.groupBox4.Controls.Add(this.textBox51);
            this.groupBox4.Controls.Add(this.totalqtytxtbox1);
            this.groupBox4.Controls.Add(this.totalbillstxtbox1);
            this.groupBox4.Controls.Add(this.di1scountedamounttxtbox);
            this.groupBox4.Controls.Add(this.di1scountamounttxtbox);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.QtyTxtbox1);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.price1tbox);
            this.groupBox4.Location = new System.Drawing.Point(12, 132);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(288, 393);
            this.groupBox4.TabIndex = 24;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Order Details";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(4, 345);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 16);
            this.label15.TabIndex = 31;
            this.label15.Text = "Change:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 297);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(79, 16);
            this.label14.TabIndex = 30;
            this.label14.Text = "Cash Given:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 249);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 16);
            this.label13.TabIndex = 29;
            this.label13.Text = "Total Quantity:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 215);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 16);
            this.label12.TabIndex = 28;
            this.label12.Text = "Total Bills:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(2, 167);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(126, 16);
            this.label11.TabIndex = 27;
            this.label11.Text = "Discounted Amount:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 119);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 16);
            this.label10.TabIndex = 26;
            this.label10.Text = "Discount Amount:";
            // 
            // changetxtbox1
            // 
            this.changetxtbox1.Location = new System.Drawing.Point(94, 332);
            this.changetxtbox1.Multiline = true;
            this.changetxtbox1.Name = "changetxtbox1";
            this.changetxtbox1.Size = new System.Drawing.Size(182, 46);
            this.changetxtbox1.TabIndex = 25;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(94, 280);
            this.textBox51.Multiline = true;
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(182, 46);
            this.textBox51.TabIndex = 24;
            // 
            // totalqtytxtbox1
            // 
            this.totalqtytxtbox1.Location = new System.Drawing.Point(104, 243);
            this.totalqtytxtbox1.Multiline = true;
            this.totalqtytxtbox1.Name = "totalqtytxtbox1";
            this.totalqtytxtbox1.Size = new System.Drawing.Size(172, 31);
            this.totalqtytxtbox1.TabIndex = 23;
            // 
            // totalbillstxtbox1
            // 
            this.totalbillstxtbox1.Location = new System.Drawing.Point(94, 203);
            this.totalbillstxtbox1.Multiline = true;
            this.totalbillstxtbox1.Name = "totalbillstxtbox1";
            this.totalbillstxtbox1.Size = new System.Drawing.Size(182, 34);
            this.totalbillstxtbox1.TabIndex = 22;
            // 
            // di1scountedamounttxtbox
            // 
            this.di1scountedamounttxtbox.Location = new System.Drawing.Point(132, 156);
            this.di1scountedamounttxtbox.Multiline = true;
            this.di1scountedamounttxtbox.Name = "di1scountedamounttxtbox";
            this.di1scountedamounttxtbox.Size = new System.Drawing.Size(144, 43);
            this.di1scountedamounttxtbox.TabIndex = 21;
            // 
            // di1scountamounttxtbox
            // 
            this.di1scountamounttxtbox.Location = new System.Drawing.Point(116, 107);
            this.di1scountamounttxtbox.Multiline = true;
            this.di1scountamounttxtbox.Name = "di1scountamounttxtbox";
            this.di1scountamounttxtbox.Size = new System.Drawing.Size(160, 42);
            this.di1scountamounttxtbox.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Price:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Quantity:";
            // 
            // QtyTxtbox1
            // 
            this.QtyTxtbox1.Location = new System.Drawing.Point(94, 79);
            this.QtyTxtbox1.Name = "QtyTxtbox1";
            this.QtyTxtbox1.Size = new System.Drawing.Size(182, 22);
            this.QtyTxtbox1.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 183);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 16);
            this.label8.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 57);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 16);
            this.label6.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 16);
            this.label7.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 16);
            this.label5.TabIndex = 14;
            // 
            // price1tbox
            // 
            this.price1tbox.Location = new System.Drawing.Point(94, 51);
            this.price1tbox.Name = "price1tbox";
            this.price1tbox.Size = new System.Drawing.Size(182, 22);
            this.price1tbox.TabIndex = 0;
            this.price1tbox.TextChanged += new System.EventHandler(this.price1tbox_TextChanged);
            // 
            // Activity3_transfer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 530);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Name = "Activity3_transfer";
            this.Text = "Activity3_transfer";
            this.Load += new System.EventHandler(this.Activity3_transfer_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.CheckBox AChickenchkbox;
        public System.Windows.Forms.RadioButton foodARdbtn1;
        public System.Windows.Forms.CheckBox BCMchkbox;
        public System.Windows.Forms.CheckBox BMPchkbox;
        public System.Windows.Forms.CheckBox BCornchkbox;
        public System.Windows.Forms.CheckBox BChickenchkbox;
        public System.Windows.Forms.CheckBox AMPchkbox;
        public System.Windows.Forms.CheckBox ACokechkbox;
        public System.Windows.Forms.CheckBox ACornchkbox;
        public System.Windows.Forms.CheckBox Aricechkbox;
        public System.Windows.Forms.RadioButton foodBRdbtn1;
        public System.Windows.Forms.TextBox changetxtbox1;
        public System.Windows.Forms.TextBox textBox51;
        public System.Windows.Forms.TextBox totalqtytxtbox1;
        public System.Windows.Forms.TextBox totalbillstxtbox1;
        public System.Windows.Forms.TextBox di1scountedamounttxtbox;
        public System.Windows.Forms.TextBox di1scountamounttxtbox;
        public System.Windows.Forms.TextBox QtyTxtbox1;
        public System.Windows.Forms.TextBox price1tbox;
    }
}