﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RODRIGUEZ_LESSON1
{
    public partial class LoginFrm : Form
    {
        public LoginFrm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (usernameTxtbox.Text == "charlesrod" && passwordTxtbox.Text == "cvr777")
            {
                MessageBox.Show("Welcome Admin Page!!!");
                MainForm adminfrm = new MainForm();
                adminfrm.Show();
                usernameTxtbox.Clear();
                passwordTxtbox.Clear();
            }
            else if (usernameTxtbox.Text == "cashier1" && passwordTxtbox.Text == "111111")
            {
                MessageBox.Show("Welcome Cashier Point of Sale Page");
                Activity2 cashierfrm = new Activity2();
                cashierfrm.Show();
                usernameTxtbox.Clear();
                passwordTxtbox.Clear();
            }
            else if (usernameTxtbox.Text == "cashier2" && passwordTxtbox.Text == "222222")
            {
                MessageBox.Show("Welcome Cashier Ordering Page");
                Activity3 cashierfrm = new Activity3();
                cashierfrm.Show();
                usernameTxtbox.Clear();
                passwordTxtbox.Clear();
            }
            else if (usernameTxtbox.Text == "payroll" && passwordTxtbox.Text == "333333")
            {
                MessageBox.Show("Welcome Payroll Page");
                Activity5 payrollfrm = new Activity5();
                payrollfrm.Show();
                usernameTxtbox.Clear();
                passwordTxtbox.Clear();
            }
            else
                MessageBox.Show("Invalid User Account!!!");
                usernameTxtbox.Clear();
                passwordTxtbox.Clear();
        }

        private void LoginFrm_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            usernameTxtbox.Focus();
        }

        private void usernameTxtbox_TextChanged(object sender, EventArgs e)
        {
            usernameTxtbox.Focus();
        }
    }
}
