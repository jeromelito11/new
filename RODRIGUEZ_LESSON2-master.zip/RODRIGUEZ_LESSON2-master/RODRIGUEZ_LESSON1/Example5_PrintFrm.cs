﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RODRIGUEZ_LESSON1
{
    public partial class Example5_PrintFrm : Form
    {
        public Example5_PrintFrm()
        {
            InitializeComponent();
        }

        public void Activity5_PrintFrm_Load(object sender, EventArgs e)
        {

        }
    }
}
