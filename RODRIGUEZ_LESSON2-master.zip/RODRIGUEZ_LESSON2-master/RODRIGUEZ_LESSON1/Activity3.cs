﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RODRIGUEZ_LESSON1
{
    public partial class Activity3 : Form
    {
        // for declaring a variable that is accessible to the whole form and can be  acces for one object to another
        private double total_amount = 0;
        private int total_qty = 0;
        private double qty = 0;
        public Activity3()
        {
            InitializeComponent();
        }
        private void quantityTxtbox()
        {
            QtyTxtbox.Clear();
            QtyTxtbox.Focus();
        }
        private void item_pricevalue(string disc_amt, string price)
        { 
            discountamounttxtbox.Text = disc_amt;
            priceTxtbox.Text = price;
        }
        double cash_given, change, total_amountPaid;
        double price, discounted_amount, discount_amount;
        private void Activity3_Load(object sender, EventArgs e)
        {
            //code for changing the form background
            this.BackColor = Color.LightYellow;
            // disabling textboxes
            priceTxtbox.Enabled = false;
            discountedamounttxtbox.Enabled = false;
            discountamounttxtbox.Enabled = false;
            totalbillstxtbox.Enabled = false;
            totalqtytxtbox.Enabled = false;
            changetxtbox.Enabled = false;
            // for inserting to picture box
            pictureBox6.Image = Image.FromFile("C:\\forms\\psa.jpg");
            pictureBox7.Image = Image.FromFile("C:\\forms\\psb.jpg");
            pictureBox8.Image = Image.FromFile("C:\\forms\\psc.jpg");
            pictureBox9.Image = Image.FromFile("C:\\forms\\psd.jpg");
            pictureBox10.Image = Image.FromFile("C:\\forms\\pb.jpg");
            pictureBox11.Image = Image.FromFile("C:\\forms\\p1.jpg");
            pictureBox12.Image = Image.FromFile("C:\\forms\\p2.jpg");
            pictureBox13.Image = Image.FromFile("C:\\forms\\p3.jpg");
            pictureBox14.Image = Image.FromFile("C:\\forms\\p4.jpg");
            pictureBox15.Image = Image.FromFile("C:\\forms\\p5.jpg");
            pictureBox16.Image = Image.FromFile("C:\\forms\\p6.jpg");
            pictureBox17.Image = Image.FromFile("C:\\forms\\p7.jpg");
            pictureBox18.Image = Image.FromFile("C:\\forms\\p8.jpg");
            pictureBox19.Image = Image.FromFile("C:\\forms\\p9.jpg");
            pictureBox20.Image = Image.FromFile("C:\\forms\\p10.jpg");
            // code for disabling checkboxes
            AChickenchkbox1.Enabled = false;
            ACokechkbox.Enabled = false;
            Aricechkbox.Enabled = false;
            ACornchkbox.Enabled = false;
            AMPchkbox.Enabled = false;
            BChickenchkbox.Enabled = false;
            BCornchkbox.Enabled = false;
            BMPchkbox.Enabled = false;
            BCMchkbox.Enabled = false;

            this.WindowState = FormWindowState.Maximized;

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            double price;
            //code for changing the form background
            this.BackColor = Color.LightCyan;
            //code for food bundle B not to be selected
            foodBRdbtn.Checked = false;
            //inserting image inside the picturebox
            DisplayPictureBox.Image = Image. FromFile("C:\\Users\\cvrro\\OneDrive\\Desktop\\forms\\fma.jpg");

            AChickenchkbox1.Checked = true;
            ACokechkbox.Checked = true;
            Aricechkbox.Checked = true;
            ACornchkbox.Checked = true;
            AMPchkbox.Checked = true;

            BChickenchkbox.Checked = false;
            BCornchkbox.Checked = false;
            BMPchkbox.Checked = false;
            BCMchkbox.Checked = false;

            priceTxtbox.Text = "1299.00";
            discountamounttxtbox.Text = "300.00";
            price = Convert.ToDouble(priceTxtbox.Text);

            listBox1.Items.Add(foodARdbtn.Text + "" + priceTxtbox.Text);
            listBox1.Items.Add("Discount Amount: "+" " + discountamounttxtbox.Text);

            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();

        }

        private void foodBRdbtn_CheckedChanged(object sender, EventArgs e)
        {
            //code for changing the form background
            this.BackColor = Color.LightBlue;
            //code for food bundle B not to be selected
            foodARdbtn.Checked = false;
            //inserting image inside the picturebox
            DisplayPictureBox.Image = Image.FromFile("C:\\Users\\cvrro\\OneDrive\\Desktop\\forms\\fmb.jpg");

            AChickenchkbox1.Checked = false;
            ACokechkbox.Checked = false;
            Aricechkbox.Checked = false;
            ACornchkbox.Checked = false;
            AMPchkbox.Checked = false;

            BChickenchkbox.Checked = true;
            BCornchkbox.Checked = true;
            BMPchkbox.Checked = true;
            BCMchkbox.Checked = true;

            priceTxtbox.Text = "1000.00";
            discountamounttxtbox.Text = "200.00";
            listBox1.Items.Add(foodARdbtn.Text);

            listBox1.Items.Add(foodBRdbtn.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            priceTxtbox.Text = "0.00";
            QtyTxtbox.Text = "0";
            //code to uncheck all given checkboxes
            foodARdbtn.Checked = false;
            foodBRdbtn.Checked = false;
            //inserting image inside the picturebox
            DisplayPictureBox.Image = Image.FromFile("C:\\Users\\cvrro\\OneDrive\\Desktop\\forms\\null.jpg");

            AChickenchkbox1.Checked = false;
            ACokechkbox.Checked = false;
            Aricechkbox.Checked = false;
            ACornchkbox.Checked = false;
            AMPchkbox.Checked = false;
            BChickenchkbox.Checked = false;
            BCornchkbox.Checked = false;
            BMPchkbox.Checked = false;
            BCMchkbox.Checked = false;

            discountamounttxtbox.Clear();
            discountedamounttxtbox.Clear();
            totalbillstxtbox.Clear();
            totalqtytxtbox.Clear();
            textBox5.Clear();
            changetxtbox.Clear();

            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
            checkBox6.Checked = false;
            checkBox7.Checked = false;
            checkBox8.Checked = false;
            checkBox9.Checked = false;
            checkBox10.Checked = false;
            checkBox11.Checked = false;
            checkBox12.Checked = false;
            checkBox13.Checked = false;
            checkBox14.Checked = false;
            checkBox15.Checked = false;
            checkBox16.Checked = false;
            checkBox17.Checked = false;
            checkBox18.Checked = false;
            checkBox19.Checked = false;
            checkBox20.Checked = false;

            listBox1.Items.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                cash_given = Convert.ToDouble(textBox5.Text);
                total_amountPaid = Convert.ToDouble(totalbillstxtbox.Text);
                change = cash_given - total_amountPaid;
                changetxtbox.Text = change.ToString("n");
                listBox1.Items.Add("Total Bills: " + "" + totalbillstxtbox.Text);
                listBox1.Items.Add("Cash Given: " + "" + textBox5.Text);
                listBox1.Items.Add("Change: " + "" + changetxtbox.Text);
                listBox1.Items.Add("Total No. of Items: " + "" + totalqtytxtbox.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter valid data in cash given textbox!");
                textBox5.Clear();
                textBox5.Focus();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Activity3_PrintFrm print = new Activity3_PrintFrm();
            print.listBox10.Items.AddRange(this.listBox1.Items);
            print.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            }
            catch
            {
                MessageBox.Show("There is no highlighted item in list");
            }

        
        }

        private void QtyTxtbox_TextChanged(object sender, EventArgs e)
        {
            int qty;
            try
            {
                price = Convert.ToDouble(priceTxtbox.Text);
                qty = Convert.ToInt32(QtyTxtbox.Text);
                discount_amount = Convert.ToDouble(discountamounttxtbox.Text);
                discounted_amount = (price * qty) - discount_amount;
                total_qty += qty;
                totalqtytxtbox.Text = total_qty.ToString();
                total_amount += discounted_amount;
                totalbillstxtbox.Text = total_amount.ToString("n");
                discountedamounttxtbox.Text = discounted_amount.ToString("n");
            }
            catch (Exception)
            {
                MessageBox.Show("Enter number of quantity ordered!");
                QtyTxtbox.Focus();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Activity3_transfer copy = new Activity3_transfer();
            
            copy.AChickenchkbox.Checked = AChickenchkbox1.Checked;
            copy.ACokechkbox.Checked = ACokechkbox.Checked;
            copy.ACornchkbox.Checked = ACornchkbox.Checked;
            copy.Aricechkbox.Checked = Aricechkbox.Checked;
            copy.AMPchkbox.Checked = AMPchkbox.Checked;

            copy.BChickenchkbox.Checked = BChickenchkbox.Checked;
            copy.BCornchkbox.Checked = BCornchkbox.Checked;
            copy.BMPchkbox.Checked = BMPchkbox.Checked;
            copy.BCMchkbox.Checked = BCMchkbox.Checked;

            copy.foodARdbtn1.Checked = foodARdbtn.Checked;
            copy.foodBRdbtn1.Checked = foodBRdbtn.Checked;

            copy.price1tbox.Text = priceTxtbox.Text;
            copy.QtyTxtbox1.Text = QtyTxtbox.Text;
            copy.di1scountamounttxtbox.Text = discountamounttxtbox.Text;
            copy.di1scountedamounttxtbox.Text = discountedamounttxtbox.Text;
            copy.totalbillstxtbox1.Text = totalbillstxtbox.Text;
            copy.totalqtytxtbox1.Text = totalqtytxtbox.Text;
            copy.textBox51.Text = textBox5.Text;
            copy.changetxtbox1.Text = changetxtbox.Text;

            copy.Show();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            // to declare a variable with specific data type
            /*double price;
            // for putting text properly value of the textboxe
            discountamounttxtbox.Text = "0.00";
            priceTxtbox.Text = "500.99";
            // to convert string data inside the textbox to numeric data to store inside the variable
            price = Convert.ToDouble(priceTxtbox.Text);
            // to insert text property value of a checkboc inside the listbox
            listBox1.Items.Add(checkBox1.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            // for the cursor inside the textbox once the event of the object triggered
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "500.99");
            quantityTxtbox();

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "550.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox2.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "550.99");
            quantityTxtbox();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "700.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox3.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "500.99");
            quantityTxtbox();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "500.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox4.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "700.99");
            quantityTxtbox();
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "750.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox5.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "500.00");
            quantityTxtbox();
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "700.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox6.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "750.00");
            quantityTxtbox();
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "850.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox7.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "700.00");
            quantityTxtbox();
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "450.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox8.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "850.00");
            quantityTxtbox();
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "650.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox9.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "450.00");
            quantityTxtbox();
        }

        private void checkBox10_CheckedChanged_1(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "675.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox10.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "650.00");
            quantityTxtbox();
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "570.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox11.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "575.00");
            quantityTxtbox();
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "575.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox12.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "575.00");
            quantityTxtbox();
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "875.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox13.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "575.00");
            quantityTxtbox();
        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "575.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox14.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "575.00");
            quantityTxtbox();
        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "575.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox15.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "575.00");
            quantityTxtbox();
        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "575.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox16.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "575.00");
            quantityTxtbox();
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "575.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox17.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "575.00");
            quantityTxtbox();
        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "850.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox18.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "575.00");
            quantityTxtbox();
        }

        private void checkBox19_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "750.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox19.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "575.00");
            quantityTxtbox();
        }

        private void checkBox20_CheckedChanged(object sender, EventArgs e)
        {
            /*double price;
            priceTxtbox.Text = "700.00";
            discountamounttxtbox.Text = "0.00";
            price = Convert.ToDouble(priceTxtbox.Text);
            listBox1.Items.Add(checkBox20.Text + "" + priceTxtbox.Text);
            QtyTxtbox.Text = "0";
            QtyTxtbox.Focus();*/
            item_pricevalue("0.00", "575.00");
            quantityTxtbox();
        }

        private void priceTxtbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
