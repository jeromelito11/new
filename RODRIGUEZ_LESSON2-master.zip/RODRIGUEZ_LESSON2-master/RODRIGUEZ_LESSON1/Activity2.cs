﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace RODRIGUEZ_LESSON1
{
    public partial class Activity2 : Form
    {
        private double qty_total = 0;
        private double discount_totalgiven = 0;
        private double discounted_total = 0;
        public Activity2()
        {
            InitializeComponent();
        }
        private void quantityTxtbox()
        {
            quantitytxtbox.Clear();
            quantitytxtbox.Focus();
        }
        private void quantity_price_Convert()
        {
            qty = Convert.ToInt32(quantitytxtbox.Text);
            price = Convert.ToDouble(pricetextbox.Text);
        }
        private double price, discounted_amt, discount_amt, cash_rendered, change;
        private int qty;
        private void computation_Formula_and_Display()
        {
            discounted_amt = (qty * price) - discount_amt;
            discounttxtbox.Text = discount_amt.ToString("n");
            discountedtxtbox.Text = discounted_amt.ToString("n");
        }
        public void price_item_TextValue(string itemname, string price)
        {
            itemnametxtbox.Text = itemname;
            pricetextbox.Text = price;
        }
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = label3.Text;
            pricetextbox.Text = "100.00";*/
            price_item_TextValue(label3.Text, "100.00");
            quantityTxtbox();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = label9.Text;
            pricetextbox.Text = "65.00";*/
            price_item_TextValue(label9.Text, "65.00");
            quantityTxtbox();
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = "KFC Group Meal";
            pricetextbox.Text = "95.00";*/
            price_item_TextValue(label14.Text, "95.00");
            quantityTxtbox();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = label7.Text;
            pricetextbox.Text = "150.00";*/
            price_item_TextValue(label7.Text, "150.00");
            quantityTxtbox();
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = "Jolly Shake";
            pricetextbox.Text = "65.00";*/
            price_item_TextValue(label12.Text, "65.00");
            quantityTxtbox();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Activity2_Load(object sender, EventArgs e)
        {
            // codes for disabling the textboxes
            itemnametxtbox.Enabled = false;
            pricetextbox.Enabled = false;
            discountedtxtbox.Enabled = false;
            qty_totaltxtbox.Enabled = false;
            discount_totaltxtbox.Enabled = false;
            discounted_totaltxtbox.Enabled = false;
            changetxtbox.Enabled = false;
            discounttxtbox.Enabled = false;
            // codes for inserting picture or image inside the picturebox tool
            pictureBox20.Image = System.Drawing.Image.FromFile("C:\\forms\\fmb.jpg");
            pictureBox19.Image = System.Drawing.Image.FromFile("C:\\forms\\combokfc.jpg");
            pictureBox18.Image = System.Drawing.Image.FromFile("C:\\forms\\gmb.jpg");
            pictureBox17.Image = System.Drawing.Image.FromFile("C:\\forms\\chow.jpg");
            pictureBox16.Image = System.Drawing.Image.FromFile("C:\\forms\\strip.jpg");
            // codes for inserting name of the image inside the label tool.
            label1.Text = "Combo Meal A";
            label2.Text = "Breakfase Meal 1";
            label3.Text = "Breakfast Meal 2";
            label4.Text = "Chicken Meal A";
            label5.Text = "Combo Meal B";
            label10.Text = "Family Meal A";
            label9.Text = "Twin Fries";
            label8.Text = "Checken Spag Meal A";
            label7.Text = "Group Meal B";
            label6.Text = "Group Meal A";

            this.WindowState = FormWindowState.Maximized;
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = "KFC Combo A";
            pricetextbox.Text = "85.00";*/
            price_item_TextValue(label13.Text, "85.00");
            quantityTxtbox();
        }

        private void pictureBox18_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = "KFC Burger Meal";
            pricetextbox.Text = "125.00";*/
            price_item_TextValue(label18.Text, "125.00");
            quantityTxtbox();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label24_Click(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = label8.Text;
            pricetextbox.Text = "95.00";*/
            price_item_TextValue(label8.Text, "95.00");
            quantityTxtbox();
        }

        private void pictureBox20_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = "KFC FaMeal B";
            pricetextbox.Text = "265.00";*/
            price_item_TextValue(label20.Text, "265.00");
            quantityTxtbox();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //codes for clearing specific pointed textboxes
            itemnametxtbox.Clear();
            pricetextbox.Clear();
            quantitytxtbox.Clear();
            discountedtxtbox.Clear();
            discounttxtbox.Clear();
            changetxtbox.Clear();
            cashre.Clear();

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            /*//Declaration of variables within a method of an object
            int qty;
            double price, discount_amt, discounted_amt;
            //convert string data from textboxes to numeric and place it as value of the variable
            qty = Convert.ToInt32(quantitytxtbox.Text);
            price = Convert.ToDouble(pricetextbox.Text);
            //create a formula needed for computation
            discount_amt = (qty * price) * 0.30;
            discounted_amt = (qty * price) - discount_amt;*/
            //converting numeric data to string and display it inside the textboxes
            {
                try
                {
                    quantity_price_Convert();
                    discount_amt = (qty * price) * 0.30;
                    computation_Formula_and_Display();
                    regularbtn.Checked = false;
                    EmployeeRdbtn.Checked = false;
                    noTaxbtn.Checked = false;
                }
                catch (Exception)
                {
                    MessageBox.Show("Input is Invalid");
                    quantityTxtbox();
                }
            }
            /*discounttxtbox.Text = discount_amt.ToString("n");
            discountedtxtbox.Text = discounted_amt.ToString("n");
            //codes for unchecking the other radio buttons in the interface once the senior citizen method executed*/
            

        }

        private void regularbtn_CheckedChanged(object sender, EventArgs e)
        {
            /*//Declaration of variables within a method of an object
            int qty;
            double price, discount_amt, discounted_amt;
            //convert string data from textboxes to numeric and place it as value of the variable
            qty = Convert.ToInt32(quantitytxtbox.Text);
            price = Convert.ToDouble(pricetextbox.Text);
            //create a formula needed for computation
            discount_amt = (qty * price) * 0.10;
            discounted_amt = (qty * price) - discount_amt;
            //converting numeric data to string and display it inside the textboxes
            discounttxtbox. Text = discount_amt.ToString("n");
            discountedtxtbox.Text = discounted_amt.ToString("n");
            //codes for unchecking the other radio buttons in the interface once the senior citizen method executed
            radiobutton1.Checked = false;
            EmployeeRdbtn.Checked = false;
            noTaxbtn.Checked = false;*/
            {
                try
                {
                    quantity_price_Convert();
                    discount_amt = (qty * price) * 0.30;
                    computation_Formula_and_Display();
                    radiobutton1.Checked = false;
                    EmployeeRdbtn.Checked = false;
                    noTaxbtn.Checked = false;
                }
                catch (Exception)
                {
                    MessageBox.Show("Input is Invalid");
                    quantityTxtbox();
                }
            }
        }

        private void EmployeeRdbtn_CheckedChanged(object sender, EventArgs e)
        {
            /*//Declaration of variables within a method of an object
            int qty;
            double price, discount_amt, discounted_amt;
            //convert string data from textboxes to numeric and place it as value of the variable
            qty = Convert.ToInt32(quantitytxtbox.Text);
            price = Convert.ToDouble(pricetextbox.Text);
            //create a formula needed for computation
            discount_amt = (qty * price) * 0.15;
            discounted_amt = (qty * price) - discount_amt;
            //converting numeric data to string and display it inside the textboxes
            discounttxtbox.Text = discount_amt.ToString("n");
            discountedtxtbox.Text = discounted_amt.ToString("n");
            //codes for unchecking the other radio buttons in the interface once the senior citizen method executed
            regularbtn.Checked = false;
            radiobutton1.Checked = false;
            noTaxbtn.Checked = false;*/
            {
                try
                {
                    quantity_price_Convert();
                    discount_amt = (qty * price) * 0.30;
                    computation_Formula_and_Display();
                    regularbtn.Checked = false;
                    radiobutton1.Checked = false;
                    noTaxbtn.Checked = false;
                }
                catch (Exception)
                {
                    MessageBox.Show("Invalid data input in quantity");
                    quantityTxtbox();
                }
            }
        }

        private void noTaxbtn_CheckedChanged(object sender, EventArgs e)
        {
            /*//Declaration of variables within a method of an object
            int qty;
            double price, discount_amt, discounted_amt;
            //convert string data from textboxes to numeric and place it as value of the variable
            qty = Convert.ToInt32(quantitytxtbox.Text);
            price = Convert.ToDouble(pricetextbox.Text);
            //create a formula needed for computation
            discount_amt = (qty * price) * 0;
            discounted_amt = (qty * price) - discount_amt;
            //converting numeric data to string and display it inside the textboxes
            discounttxtbox.Text = discount_amt.ToString("n");
            discountedtxtbox.Text = discounted_amt.ToString("n");
            //codes for unchecking the other radio buttons in the interface once the senior citizen method executed
            regularbtn.Checked = false;
            EmployeeRdbtn.Checked = false;
            radiobutton1.Checked = false;*/
            {
                try
                {
                    quantity_price_Convert();
                    discount_amt = (qty * price) * 0.30;
                    computation_Formula_and_Display();
                    regularbtn.Checked = false;
                    EmployeeRdbtn.Checked = false;
                    radiobutton1.Checked = false;
                }
                catch (Exception)
                {
                    MessageBox.Show("Invalid data input in quantity");
                    quantityTxtbox();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            /*//declaration of variables with data types
            int qty;
            double discount_amt, discounted_amt, cash_rendered, change;
            qty = Convert.ToInt32(quantitytxtbox.Text);
            discount_amt = Convert.ToDouble(discounttxtbox.Text);
            discounted_amt = Convert.ToDouble(discountedtxtbox.Text);
            cash_rendered = Convert.ToDouble(cashre.Text);
            //codes to accumulate the value of the quantity, discount given and discounted amount from one transaction to another.
            qty_total += qty;
            discount_totalgiven += discount_amt;
            discounted_total += discounted_amt;
            change = cash_rendered - discounted_amt;
            //convert string data form textboxes to numeric and place it as value of the variable
            qty_totaltxtbox.Text = qty_total.ToString();
            discount_totaltxtbox.Text = discount_totalgiven.ToString("n");
            discounted_totaltxtbox.Text = discounted_total.ToString("n");
            changetxtbox.Text = change.ToString("n");
            discountedtxtbox.Text = Convert.ToString(discount_amt);

            cashre.Text = cash_rendered.ToString("n");*/
            try
            {
                qty = Convert.ToInt32(quantitytxtbox.Text);
                discount_amt = Convert.ToDouble(discounttxtbox.Text);
                discounted_amt = Convert.ToDouble(discountedtxtbox.Text);
                cash_rendered = Convert.ToDouble(cashre.Text);

                qty_total += qty;
                discount_totalgiven += discount_amt;
                discounted_total += discounted_amt;
                change = cash_rendered - discounted_amt;
                
                qty_totaltxtbox.Text = qty_total.ToString();
                discount_totaltxtbox.Text = discount_totalgiven.ToString("n");
                discounted_totaltxtbox.Text = discounted_total.ToString("n");
                changetxtbox.Text = change.ToString("n");
                discountedtxtbox.Text = Convert.ToString(discount_amt);
                cashre.Text = cash_rendered.ToString("n");
            }
            catch (Exception)
            {
                MessageBox.Show("Make sure cash given textbox is not empty/invalid");
                cashre.Clear();
                cashre.Focus();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = "Combo Meal A";
            pricetextbox.Text = "90.00";*/
            price_item_TextValue("Combo Meal A", "90.00");
            quantityTxtbox();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = label6.Text;
            pricetextbox.Text = "165.00";*/
            price_item_TextValue(label6.Text, "165.00");
            quantityTxtbox();
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = "Spag Meal 1";
            pricetextbox.Text = "95.00";*/
            price_item_TextValue(label11.Text, "95.00");
            quantityTxtbox();
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = "KFC Chicken Strips";
            pricetextbox.Text = "105.00";*/
            price_item_TextValue(label16.Text, "105.00");
            quantityTxtbox();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = label2.Text;
            pricetextbox.Text = "95.00";*/
            price_item_TextValue(label2.Text, "95.00");
            quantityTxtbox();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = label4.Text;
            pricetextbox.Text = "105.00";*/
            price_item_TextValue(label4.Text, "105.00");
            quantityTxtbox();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = label5.Text;
            pricetextbox.Text = "120.00";*/
            price_item_TextValue(label5.Text, "120.00");
            quantityTxtbox();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = label10.Text;
            pricetextbox.Text = "150.00";*/
            price_item_TextValue(label10.Text, "150.00");
            quantityTxtbox();
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = "KFC FaMeal A";
            pricetextbox.Text = "265.00";*/
            price_item_TextValue(label15.Text, "265.00");
            quantityTxtbox();
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = "KFC ChowFun";
            pricetextbox.Text = "75.00";*/
            price_item_TextValue(label17.Text, "75.00");
            quantityTxtbox();
        }

        private void pictureBox19_Click(object sender, EventArgs e)
        {
            /*itemnametxtbox.Text = "KFC Combo B";
            pricetextbox.Text = "85.00";*/
            price_item_TextValue(label19.Text, "85.00");
            quantityTxtbox();
        }
    }
}
