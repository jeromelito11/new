﻿namespace RODRIGUEZ_LESSON1
{
    partial class L2LA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SNtxtBox = new System.Windows.Forms.TextBox();
            this.Snumtxtbox = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.yltxtbox = new System.Windows.Forms.TextBox();
            this.dtp = new System.Windows.Forms.DateTimePicker();
            this.S = new System.Windows.Forms.TextBox();
            this.cnumtxtbox = new System.Windows.Forms.TextBox();
            this.ccodetxtbox = new System.Windows.Forms.TextBox();
            this.cdesctxtbox = new System.Windows.Forms.TextBox();
            this.ultxtbox = new System.Windows.Forms.TextBox();
            this.ulabtxtbox = new System.Windows.Forms.TextBox();
            this.ttxtbox = new System.Windows.Forms.TextBox();
            this.dtxtbox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.cutxtbox = new System.Windows.Forms.TextBox();
            this.tnutxtbox = new System.Windows.Forms.TextBox();
            this.lftxtbox = new System.Windows.Forms.TextBox();
            this.ttftxtbox = new System.Windows.Forms.TextBox();
            this.tmftxtbox = new System.Windows.Forms.TextBox();
            this.clftxtbox = new System.Windows.Forms.TextBox();
            this.ebftxtbox = new System.Windows.Forms.TextBox();
            this.ttaftxtbox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.listBox7 = new System.Windows.Forms.ListBox();
            this.listBox8 = new System.Windows.Forms.ListBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.ttftxtbox2 = new System.Windows.Forms.TextBox();
            this.tmftxtbox2 = new System.Windows.Forms.TextBox();
            this.tnutxtbox2 = new System.Windows.Forms.TextBox();
            this.ttaftxtbox2 = new System.Windows.Forms.TextBox();
            this.comlbtxtbox = new System.Windows.Forms.TextBox();
            this.clftxtbox2 = new System.Windows.Forms.TextBox();
            this.ebtxtbox = new System.Windows.Forms.TextBox();
            this.tosftxtbox = new System.Windows.Forms.TextBox();
            this.calcbtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(205, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Student Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(205, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Programs:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(205, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Student Number:";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(205, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Year Level:";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(205, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Date Enrolled:";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(205, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Scholar:";
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.Location = new System.Drawing.Point(45, 150);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(97, 33);
            this.button1.TabIndex = 7;
            this.button1.Text = "Browse";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 226);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 16);
            this.label7.TabIndex = 8;
            this.label7.Text = "Course Number:";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(5, 254);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 16);
            this.label8.TabIndex = 9;
            this.label8.Text = "Course Code:";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Yellow;
            this.button2.Location = new System.Drawing.Point(606, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(111, 36);
            this.button2.TabIndex = 10;
            this.button2.Text = "Submit";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button3.Location = new System.Drawing.Point(606, 54);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 38);
            this.button3.TabIndex = 11;
            this.button3.Text = "New/Cancel";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // SNtxtBox
            // 
            this.SNtxtBox.Location = new System.Drawing.Point(317, 12);
            this.SNtxtBox.Name = "SNtxtBox";
            this.SNtxtBox.Size = new System.Drawing.Size(267, 22);
            this.SNtxtBox.TabIndex = 12;
            // 
            // Snumtxtbox
            // 
            this.Snumtxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Snumtxtbox.Location = new System.Drawing.Point(317, 70);
            this.Snumtxtbox.Name = "Snumtxtbox";
            this.Snumtxtbox.Size = new System.Drawing.Size(267, 22);
            this.Snumtxtbox.TabIndex = 13;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(317, 40);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(267, 24);
            this.comboBox1.TabIndex = 14;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            // 
            // yltxtbox
            // 
            this.yltxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.yltxtbox.Location = new System.Drawing.Point(317, 98);
            this.yltxtbox.Name = "yltxtbox";
            this.yltxtbox.Size = new System.Drawing.Size(151, 22);
            this.yltxtbox.TabIndex = 15;
            // 
            // dtp
            // 
            this.dtp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtp.Location = new System.Drawing.Point(317, 126);
            this.dtp.Name = "dtp";
            this.dtp.Size = new System.Drawing.Size(267, 22);
            this.dtp.TabIndex = 16;
            // 
            // S
            // 
            this.S.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.S.Location = new System.Drawing.Point(317, 154);
            this.S.Name = "S";
            this.S.Size = new System.Drawing.Size(267, 22);
            this.S.TabIndex = 17;
            // 
            // cnumtxtbox
            // 
            this.cnumtxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cnumtxtbox.Location = new System.Drawing.Point(112, 223);
            this.cnumtxtbox.Name = "cnumtxtbox";
            this.cnumtxtbox.Size = new System.Drawing.Size(232, 22);
            this.cnumtxtbox.TabIndex = 18;
            // 
            // ccodetxtbox
            // 
            this.ccodetxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ccodetxtbox.Location = new System.Drawing.Point(112, 251);
            this.ccodetxtbox.Name = "ccodetxtbox";
            this.ccodetxtbox.Size = new System.Drawing.Size(232, 22);
            this.ccodetxtbox.TabIndex = 19;
            // 
            // cdesctxtbox
            // 
            this.cdesctxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cdesctxtbox.Location = new System.Drawing.Point(112, 279);
            this.cdesctxtbox.Name = "cdesctxtbox";
            this.cdesctxtbox.Size = new System.Drawing.Size(232, 22);
            this.cdesctxtbox.TabIndex = 20;
            // 
            // ultxtbox
            // 
            this.ultxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ultxtbox.Location = new System.Drawing.Point(112, 307);
            this.ultxtbox.Name = "ultxtbox";
            this.ultxtbox.Size = new System.Drawing.Size(232, 22);
            this.ultxtbox.TabIndex = 21;
            // 
            // ulabtxtbox
            // 
            this.ulabtxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ulabtxtbox.Location = new System.Drawing.Point(112, 335);
            this.ulabtxtbox.Name = "ulabtxtbox";
            this.ulabtxtbox.Size = new System.Drawing.Size(232, 22);
            this.ulabtxtbox.TabIndex = 22;
            // 
            // ttxtbox
            // 
            this.ttxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ttxtbox.Location = new System.Drawing.Point(112, 363);
            this.ttxtbox.Name = "ttxtbox";
            this.ttxtbox.Size = new System.Drawing.Size(232, 22);
            this.ttxtbox.TabIndex = 23;
            // 
            // dtxtbox
            // 
            this.dtxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtxtbox.Location = new System.Drawing.Point(112, 391);
            this.dtxtbox.Name = "dtxtbox";
            this.dtxtbox.Size = new System.Drawing.Size(232, 22);
            this.dtxtbox.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 282);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 16);
            this.label9.TabIndex = 25;
            this.label9.Text = "Course Desc:";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 310);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 16);
            this.label10.TabIndex = 26;
            this.label10.Text = "Unit Lecture:";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(5, 338);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 16);
            this.label11.TabIndex = 27;
            this.label11.Text = "Unit Laboratory:";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(5, 366);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 16);
            this.label12.TabIndex = 28;
            this.label12.Text = "Time:";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(5, 394);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 16);
            this.label13.TabIndex = 29;
            this.label13.Text = "Day:";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(350, 229);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 16);
            this.label14.TabIndex = 30;
            this.label14.Text = "Credit Units:";
            // 
            // cutxtbox
            // 
            this.cutxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cutxtbox.Location = new System.Drawing.Point(506, 226);
            this.cutxtbox.Name = "cutxtbox";
            this.cutxtbox.Size = new System.Drawing.Size(214, 22);
            this.cutxtbox.TabIndex = 31;
            // 
            // tnutxtbox
            // 
            this.tnutxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tnutxtbox.Location = new System.Drawing.Point(506, 254);
            this.tnutxtbox.Name = "tnutxtbox";
            this.tnutxtbox.Size = new System.Drawing.Size(214, 22);
            this.tnutxtbox.TabIndex = 32;
            // 
            // lftxtbox
            // 
            this.lftxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lftxtbox.Location = new System.Drawing.Point(506, 282);
            this.lftxtbox.Name = "lftxtbox";
            this.lftxtbox.Size = new System.Drawing.Size(214, 22);
            this.lftxtbox.TabIndex = 33;
            // 
            // ttftxtbox
            // 
            this.ttftxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ttftxtbox.Location = new System.Drawing.Point(506, 310);
            this.ttftxtbox.Name = "ttftxtbox";
            this.ttftxtbox.Size = new System.Drawing.Size(214, 22);
            this.ttftxtbox.TabIndex = 34;
            // 
            // tmftxtbox
            // 
            this.tmftxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tmftxtbox.Location = new System.Drawing.Point(506, 338);
            this.tmftxtbox.Name = "tmftxtbox";
            this.tmftxtbox.Size = new System.Drawing.Size(214, 22);
            this.tmftxtbox.TabIndex = 35;
            this.tmftxtbox.TextChanged += new System.EventHandler(this.tmftxtbox_TextChanged);
            // 
            // clftxtbox
            // 
            this.clftxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.clftxtbox.Location = new System.Drawing.Point(506, 366);
            this.clftxtbox.Name = "clftxtbox";
            this.clftxtbox.Size = new System.Drawing.Size(214, 22);
            this.clftxtbox.TabIndex = 36;
            // 
            // ebftxtbox
            // 
            this.ebftxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ebftxtbox.Location = new System.Drawing.Point(506, 394);
            this.ebftxtbox.Name = "ebftxtbox";
            this.ebftxtbox.Size = new System.Drawing.Size(214, 22);
            this.ebftxtbox.TabIndex = 37;
            // 
            // ttaftxtbox
            // 
            this.ttaftxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ttaftxtbox.Location = new System.Drawing.Point(506, 422);
            this.ttaftxtbox.Name = "ttaftxtbox";
            this.ttaftxtbox.Size = new System.Drawing.Size(214, 22);
            this.ttaftxtbox.TabIndex = 38;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(350, 257);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(141, 16);
            this.label15.TabIndex = 39;
            this.label15.Text = "Total Number Of Units:";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(350, 285);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(102, 16);
            this.label16.TabIndex = 40;
            this.label16.Text = "Laboratory Fee:";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(350, 313);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(111, 16);
            this.label17.TabIndex = 41;
            this.label17.Text = "Total Tuition Fee:";
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(350, 341);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(150, 16);
            this.label18.TabIndex = 42;
            this.label18.Text = "Total Miscellenous Fee:";
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(350, 369);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(97, 16);
            this.label19.TabIndex = 43;
            this.label19.Text = "Cisco Lab Fee:";
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(350, 397);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(120, 16);
            this.label20.TabIndex = 44;
            this.label20.Text = "Exam Booklet Fee:";
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(350, 425);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(137, 16);
            this.label21.TabIndex = 45;
            this.label21.Text = "Total Tuition and Fee:";
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(12, 464);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(14, 16);
            this.label22.TabIndex = 46;
            this.label22.Text = "#";
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(35, 465);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(93, 16);
            this.label23.TabIndex = 47;
            this.label23.Text = "CoursenCode:";
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(135, 465);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(88, 16);
            this.label24.TabIndex = 48;
            this.label24.Text = "Course Desc:";
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(296, 465);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(58, 16);
            this.label25.TabIndex = 49;
            this.label25.Text = "Unit Lec:";
            // 
            // label26
            // 
            this.label26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(369, 465);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(59, 16);
            this.label26.TabIndex = 50;
            this.label26.Text = "Unit Lab:";
            // 
            // label27
            // 
            this.label27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(446, 465);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(78, 16);
            this.label27.TabIndex = 51;
            this.label27.Text = "Credit Units:";
            // 
            // label28
            // 
            this.label28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(530, 465);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(41, 16);
            this.label28.TabIndex = 52;
            this.label28.Text = "Time:";
            // 
            // label29
            // 
            this.label29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(623, 465);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(35, 16);
            this.label29.TabIndex = 53;
            this.label29.Text = "Day:";
            // 
            // listBox1
            // 
            this.listBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(8, 484);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(26, 148);
            this.listBox1.TabIndex = 54;
            // 
            // listBox2
            // 
            this.listBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 16;
            this.listBox2.Location = new System.Drawing.Point(34, 484);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(98, 148);
            this.listBox2.TabIndex = 55;
            // 
            // listBox3
            // 
            this.listBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 16;
            this.listBox3.Location = new System.Drawing.Point(132, 484);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(158, 148);
            this.listBox3.TabIndex = 56;
            // 
            // listBox4
            // 
            this.listBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listBox4.FormattingEnabled = true;
            this.listBox4.ItemHeight = 16;
            this.listBox4.Location = new System.Drawing.Point(290, 484);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(75, 148);
            this.listBox4.TabIndex = 57;
            // 
            // listBox5
            // 
            this.listBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listBox5.FormattingEnabled = true;
            this.listBox5.ItemHeight = 16;
            this.listBox5.Location = new System.Drawing.Point(365, 484);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(75, 148);
            this.listBox5.TabIndex = 58;
            this.listBox5.SelectedIndexChanged += new System.EventHandler(this.ListBox5_SelectedIndexChanged);
            // 
            // listBox6
            // 
            this.listBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listBox6.FormattingEnabled = true;
            this.listBox6.ItemHeight = 16;
            this.listBox6.Location = new System.Drawing.Point(440, 484);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(92, 148);
            this.listBox6.TabIndex = 59;
            // 
            // listBox7
            // 
            this.listBox7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listBox7.FormattingEnabled = true;
            this.listBox7.ItemHeight = 16;
            this.listBox7.Location = new System.Drawing.Point(532, 484);
            this.listBox7.Name = "listBox7";
            this.listBox7.Size = new System.Drawing.Size(94, 148);
            this.listBox7.TabIndex = 60;
            // 
            // listBox8
            // 
            this.listBox8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listBox8.FormattingEnabled = true;
            this.listBox8.ItemHeight = 16;
            this.listBox8.Location = new System.Drawing.Point(626, 484);
            this.listBox8.Name = "listBox8";
            this.listBox8.Size = new System.Drawing.Size(94, 148);
            this.listBox8.TabIndex = 61;
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(5, 659);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(111, 16);
            this.label30.TabIndex = 62;
            this.label30.Text = "Total Tuition Fee:";
            // 
            // label31
            // 
            this.label31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(5, 687);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(150, 16);
            this.label31.TabIndex = 63;
            this.label31.Text = "Total Miscellenous Fee:";
            // 
            // label32
            // 
            this.label32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(322, 659);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(139, 16);
            this.label32.TabIndex = 64;
            this.label32.Text = "Total Number of Units:";
            // 
            // label33
            // 
            this.label33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(322, 687);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(144, 16);
            this.label33.TabIndex = 65;
            this.label33.Text = "Total Tuition and Fees:";
            // 
            // label34
            // 
            this.label34.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(5, 723);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(121, 16);
            this.label34.TabIndex = 66;
            this.label34.Text = "Other School Fees:";
            // 
            // label35
            // 
            this.label35.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(42, 754);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(163, 16);
            this.label35.TabIndex = 67;
            this.label35.Text = "Computer Laboratory Fee:";
            // 
            // label36
            // 
            this.label36.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(42, 782);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(97, 16);
            this.label36.TabIndex = 68;
            this.label36.Text = "Cisco Lab Fee:";
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(42, 810);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(93, 16);
            this.label37.TabIndex = 69;
            this.label37.Text = "Exam Booklet:";
            // 
            // label38
            // 
            this.label38.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(5, 838);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(155, 16);
            this.label38.TabIndex = 70;
            this.label38.Text = "Total Other School Fees:";
            // 
            // ttftxtbox2
            // 
            this.ttftxtbox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ttftxtbox2.Location = new System.Drawing.Point(122, 656);
            this.ttftxtbox2.Name = "ttftxtbox2";
            this.ttftxtbox2.Size = new System.Drawing.Size(189, 22);
            this.ttftxtbox2.TabIndex = 71;
            // 
            // tmftxtbox2
            // 
            this.tmftxtbox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tmftxtbox2.Location = new System.Drawing.Point(161, 684);
            this.tmftxtbox2.Name = "tmftxtbox2";
            this.tmftxtbox2.Size = new System.Drawing.Size(150, 22);
            this.tmftxtbox2.TabIndex = 72;
            // 
            // tnutxtbox2
            // 
            this.tnutxtbox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tnutxtbox2.Location = new System.Drawing.Point(467, 656);
            this.tnutxtbox2.Name = "tnutxtbox2";
            this.tnutxtbox2.Size = new System.Drawing.Size(227, 22);
            this.tnutxtbox2.TabIndex = 73;
            // 
            // ttaftxtbox2
            // 
            this.ttaftxtbox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ttaftxtbox2.Location = new System.Drawing.Point(467, 684);
            this.ttaftxtbox2.Name = "ttaftxtbox2";
            this.ttaftxtbox2.Size = new System.Drawing.Size(227, 22);
            this.ttaftxtbox2.TabIndex = 74;
            // 
            // comlbtxtbox
            // 
            this.comlbtxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comlbtxtbox.Location = new System.Drawing.Point(208, 751);
            this.comlbtxtbox.Name = "comlbtxtbox";
            this.comlbtxtbox.Size = new System.Drawing.Size(146, 22);
            this.comlbtxtbox.TabIndex = 75;
            // 
            // clftxtbox2
            // 
            this.clftxtbox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.clftxtbox2.Location = new System.Drawing.Point(145, 779);
            this.clftxtbox2.Name = "clftxtbox2";
            this.clftxtbox2.Size = new System.Drawing.Size(209, 22);
            this.clftxtbox2.TabIndex = 76;
            // 
            // ebtxtbox
            // 
            this.ebtxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ebtxtbox.Location = new System.Drawing.Point(145, 807);
            this.ebtxtbox.Name = "ebtxtbox";
            this.ebtxtbox.Size = new System.Drawing.Size(209, 22);
            this.ebtxtbox.TabIndex = 77;
            // 
            // tosftxtbox
            // 
            this.tosftxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tosftxtbox.Location = new System.Drawing.Point(166, 835);
            this.tosftxtbox.Name = "tosftxtbox";
            this.tosftxtbox.Size = new System.Drawing.Size(188, 22);
            this.tosftxtbox.TabIndex = 78;
            // 
            // calcbtn
            // 
            this.calcbtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.calcbtn.BackColor = System.Drawing.Color.Red;
            this.calcbtn.Location = new System.Drawing.Point(606, 98);
            this.calcbtn.Name = "calcbtn";
            this.calcbtn.Size = new System.Drawing.Size(111, 46);
            this.calcbtn.TabIndex = 79;
            this.calcbtn.Text = "Calculate";
            this.calcbtn.UseVisualStyleBackColor = false;
            this.calcbtn.Click += new System.EventHandler(this.button4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(177, 132);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // L2LA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(729, 869);
            this.Controls.Add(this.calcbtn);
            this.Controls.Add(this.tosftxtbox);
            this.Controls.Add(this.ebtxtbox);
            this.Controls.Add(this.clftxtbox2);
            this.Controls.Add(this.comlbtxtbox);
            this.Controls.Add(this.ttaftxtbox2);
            this.Controls.Add(this.tnutxtbox2);
            this.Controls.Add(this.tmftxtbox2);
            this.Controls.Add(this.ttftxtbox2);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.listBox8);
            this.Controls.Add(this.listBox7);
            this.Controls.Add(this.listBox6);
            this.Controls.Add(this.listBox5);
            this.Controls.Add(this.listBox4);
            this.Controls.Add(this.listBox3);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.ttaftxtbox);
            this.Controls.Add(this.ebftxtbox);
            this.Controls.Add(this.clftxtbox);
            this.Controls.Add(this.tmftxtbox);
            this.Controls.Add(this.ttftxtbox);
            this.Controls.Add(this.lftxtbox);
            this.Controls.Add(this.tnutxtbox);
            this.Controls.Add(this.cutxtbox);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dtxtbox);
            this.Controls.Add(this.ttxtbox);
            this.Controls.Add(this.ulabtxtbox);
            this.Controls.Add(this.ultxtbox);
            this.Controls.Add(this.cdesctxtbox);
            this.Controls.Add(this.ccodetxtbox);
            this.Controls.Add(this.cnumtxtbox);
            this.Controls.Add(this.S);
            this.Controls.Add(this.dtp);
            this.Controls.Add(this.yltxtbox);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.Snumtxtbox);
            this.Controls.Add(this.SNtxtBox);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "L2LA";
            this.Text = "L2LA";
            this.Load += new System.EventHandler(this.L2LA_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox SNtxtBox;
        private System.Windows.Forms.TextBox Snumtxtbox;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox yltxtbox;
        private System.Windows.Forms.DateTimePicker dtp;
        private System.Windows.Forms.TextBox S;
        private System.Windows.Forms.TextBox cnumtxtbox;
        private System.Windows.Forms.TextBox ccodetxtbox;
        private System.Windows.Forms.TextBox cdesctxtbox;
        private System.Windows.Forms.TextBox ultxtbox;
        private System.Windows.Forms.TextBox ulabtxtbox;
        private System.Windows.Forms.TextBox ttxtbox;
        private System.Windows.Forms.TextBox dtxtbox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox cutxtbox;
        private System.Windows.Forms.TextBox tnutxtbox;
        private System.Windows.Forms.TextBox lftxtbox;
        private System.Windows.Forms.TextBox ttftxtbox;
        private System.Windows.Forms.TextBox tmftxtbox;
        private System.Windows.Forms.TextBox clftxtbox;
        private System.Windows.Forms.TextBox ebftxtbox;
        private System.Windows.Forms.TextBox ttaftxtbox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.ListBox listBox6;
        private System.Windows.Forms.ListBox listBox7;
        private System.Windows.Forms.ListBox listBox8;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox ttftxtbox2;
        private System.Windows.Forms.TextBox tmftxtbox2;
        private System.Windows.Forms.TextBox tnutxtbox2;
        private System.Windows.Forms.TextBox ttaftxtbox2;
        private System.Windows.Forms.TextBox comlbtxtbox;
        private System.Windows.Forms.TextBox clftxtbox2;
        private System.Windows.Forms.TextBox ebtxtbox;
        private System.Windows.Forms.TextBox tosftxtbox;
        private System.Windows.Forms.Button calcbtn;
    }
}