﻿namespace RODRIGUEZ_LESSON1
{
    partial class Activity5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employeetxtbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.deptxtbox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.nitxtbox = new System.Windows.Forms.TextBox();
            this.gitxtbox = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ico3txtbox = new System.Windows.Forms.TextBox();
            this.nhco3txtbox = new System.Windows.Forms.TextBox();
            this.rate3txtbox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ico2txtbox = new System.Windows.Forms.TextBox();
            this.nhco2txtbox = new System.Windows.Forms.TextBox();
            this.rate2txtbox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ico1txtbox = new System.Windows.Forms.TextBox();
            this.nhco1txtbox = new System.Windows.Forms.TextBox();
            this.rate1txtbox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tdtxtbox = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.otxtbox = new System.Windows.Forms.TextBox();
            this.sltxtbox = new System.Windows.Forms.TextBox();
            this.fsltxtbox = new System.Windows.Forms.TextBox();
            this.fsdtxtbox = new System.Windows.Forms.TextBox();
            this.piltxtbox = new System.Windows.Forms.TextBox();
            this.sssltxtbox = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ttxtbox = new System.Windows.Forms.TextBox();
            this.pctxtbox = new System.Windows.Forms.TextBox();
            this.phctxtbox = new System.Windows.Forms.TextBox();
            this.sssctxtbox = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.cstxtbox = new System.Windows.Forms.TextBox();
            this.snametxtbox = new System.Windows.Forms.TextBox();
            this.mnametxtbox = new System.Windows.Forms.TextBox();
            this.fnametxtbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.estxtbox = new System.Windows.Forms.TextBox();
            this.nodtxtbox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dtxtbox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.newtxtbox = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // employeetxtbox
            // 
            this.employeetxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.employeetxtbox.Location = new System.Drawing.Point(147, 241);
            this.employeetxtbox.Multiline = true;
            this.employeetxtbox.Name = "employeetxtbox";
            this.employeetxtbox.Size = new System.Drawing.Size(305, 22);
            this.employeetxtbox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 241);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Employee Number:";
            // 
            // deptxtbox
            // 
            this.deptxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.deptxtbox.Location = new System.Drawing.Point(147, 269);
            this.deptxtbox.Multiline = true;
            this.deptxtbox.Name = "deptxtbox";
            this.deptxtbox.Size = new System.Drawing.Size(305, 22);
            this.deptxtbox.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 269);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 16);
            this.label10.TabIndex = 19;
            this.label10.Text = "Department:";
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox5.Controls.Add(this.nitxtbox);
            this.groupBox5.Controls.Add(this.gitxtbox);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(12, 654);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(446, 113);
            this.groupBox5.TabIndex = 22;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "INCOME SUMMARY";
            // 
            // nitxtbox
            // 
            this.nitxtbox.Location = new System.Drawing.Point(135, 66);
            this.nitxtbox.Multiline = true;
            this.nitxtbox.Name = "nitxtbox";
            this.nitxtbox.Size = new System.Drawing.Size(305, 22);
            this.nitxtbox.TabIndex = 33;
            // 
            // gitxtbox
            // 
            this.gitxtbox.Location = new System.Drawing.Point(154, 33);
            this.gitxtbox.Multiline = true;
            this.gitxtbox.Name = "gitxtbox";
            this.gitxtbox.Size = new System.Drawing.Size(286, 22);
            this.gitxtbox.TabIndex = 32;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(35, 69);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(93, 16);
            this.label21.TabIndex = 17;
            this.label21.Text = "NET INCOME:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(35, 36);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(113, 16);
            this.label20.TabIndex = 16;
            this.label20.Text = "GROSS INCOME:";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox4.Controls.Add(this.ico3txtbox);
            this.groupBox4.Controls.Add(this.nhco3txtbox);
            this.groupBox4.Controls.Add(this.rate3txtbox);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(12, 535);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(446, 113);
            this.groupBox4.TabIndex = 23;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "OTHER INCOME";
            // 
            // ico3txtbox
            // 
            this.ico3txtbox.Location = new System.Drawing.Point(191, 80);
            this.ico3txtbox.Multiline = true;
            this.ico3txtbox.Name = "ico3txtbox";
            this.ico3txtbox.Size = new System.Drawing.Size(249, 22);
            this.ico3txtbox.TabIndex = 31;
            // 
            // nhco3txtbox
            // 
            this.nhco3txtbox.Location = new System.Drawing.Point(173, 52);
            this.nhco3txtbox.Multiline = true;
            this.nhco3txtbox.Name = "nhco3txtbox";
            this.nhco3txtbox.Size = new System.Drawing.Size(267, 22);
            this.nhco3txtbox.TabIndex = 30;
            this.nhco3txtbox.TextChanged += new System.EventHandler(this.nhco3txtbox_TextChanged);
            // 
            // rate3txtbox
            // 
            this.rate3txtbox.Location = new System.Drawing.Point(126, 26);
            this.rate3txtbox.Multiline = true;
            this.rate3txtbox.Name = "rate3txtbox";
            this.rate3txtbox.Size = new System.Drawing.Size(314, 22);
            this.rate3txtbox.TabIndex = 29;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(35, 83);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(119, 16);
            this.label19.TabIndex = 28;
            this.label19.Text = "Income Per Cut Off:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(35, 55);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(132, 16);
            this.label18.TabIndex = 27;
            this.label18.Text = "No. of Hours / Cut Off:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(35, 29);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(78, 16);
            this.label17.TabIndex = 26;
            this.label17.Text = "Rate / Hour:";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox3.Controls.Add(this.ico2txtbox);
            this.groupBox3.Controls.Add(this.nhco2txtbox);
            this.groupBox3.Controls.Add(this.rate2txtbox);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(12, 416);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(446, 113);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "HONORARUIM";
            // 
            // ico2txtbox
            // 
            this.ico2txtbox.Location = new System.Drawing.Point(182, 82);
            this.ico2txtbox.Multiline = true;
            this.ico2txtbox.Name = "ico2txtbox";
            this.ico2txtbox.Size = new System.Drawing.Size(258, 22);
            this.ico2txtbox.TabIndex = 28;
            // 
            // nhco2txtbox
            // 
            this.nhco2txtbox.Location = new System.Drawing.Point(173, 49);
            this.nhco2txtbox.Multiline = true;
            this.nhco2txtbox.Name = "nhco2txtbox";
            this.nhco2txtbox.Size = new System.Drawing.Size(267, 22);
            this.nhco2txtbox.TabIndex = 27;
            this.nhco2txtbox.TextChanged += new System.EventHandler(this.nhco2txtbox_TextChanged);
            // 
            // rate2txtbox
            // 
            this.rate2txtbox.Location = new System.Drawing.Point(126, 19);
            this.rate2txtbox.Multiline = true;
            this.rate2txtbox.Name = "rate2txtbox";
            this.rate2txtbox.Size = new System.Drawing.Size(314, 22);
            this.rate2txtbox.TabIndex = 26;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(35, 85);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(119, 16);
            this.label16.TabIndex = 25;
            this.label16.Text = "Income Per Cut Off:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(35, 52);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(132, 16);
            this.label15.TabIndex = 24;
            this.label15.Text = "No. of Hours / Cut Off:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(35, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 16);
            this.label14.TabIndex = 23;
            this.label14.Text = "Rate / Hour:";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.ico1txtbox);
            this.groupBox2.Controls.Add(this.nhco1txtbox);
            this.groupBox2.Controls.Add(this.rate1txtbox);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 297);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(446, 113);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "BASIC PAY";
            // 
            // ico1txtbox
            // 
            this.ico1txtbox.Location = new System.Drawing.Point(160, 79);
            this.ico1txtbox.Multiline = true;
            this.ico1txtbox.Name = "ico1txtbox";
            this.ico1txtbox.Size = new System.Drawing.Size(280, 22);
            this.ico1txtbox.TabIndex = 24;
            // 
            // nhco1txtbox
            // 
            this.nhco1txtbox.Location = new System.Drawing.Point(173, 51);
            this.nhco1txtbox.Multiline = true;
            this.nhco1txtbox.Name = "nhco1txtbox";
            this.nhco1txtbox.Size = new System.Drawing.Size(267, 22);
            this.nhco1txtbox.TabIndex = 23;
            this.nhco1txtbox.TextChanged += new System.EventHandler(this.nhco1txtbox_TextChanged);
            // 
            // rate1txtbox
            // 
            this.rate1txtbox.Location = new System.Drawing.Point(126, 24);
            this.rate1txtbox.Multiline = true;
            this.rate1txtbox.Name = "rate1txtbox";
            this.rate1txtbox.Size = new System.Drawing.Size(314, 22);
            this.rate1txtbox.TabIndex = 20;
            this.rate1txtbox.TextChanged += new System.EventHandler(this.rate1txtbox_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 82);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 16);
            this.label13.TabIndex = 22;
            this.label13.Text = "Income Per Cut Off:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(35, 54);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(132, 16);
            this.label12.TabIndex = 21;
            this.label12.Text = "No. of Hours / Cut Off:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(35, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 16);
            this.label11.TabIndex = 20;
            this.label11.Text = "Rate / Hour:";
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox8.Controls.Add(this.tdtxtbox);
            this.groupBox8.Controls.Add(this.label32);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(464, 649);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(446, 96);
            this.groupBox8.TabIndex = 25;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "DEDUCTION SUMMARY";
            // 
            // tdtxtbox
            // 
            this.tdtxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tdtxtbox.Location = new System.Drawing.Point(159, 36);
            this.tdtxtbox.Multiline = true;
            this.tdtxtbox.Name = "tdtxtbox";
            this.tdtxtbox.Size = new System.Drawing.Size(281, 52);
            this.tdtxtbox.TabIndex = 21;
            this.tdtxtbox.TextChanged += new System.EventHandler(this.tdtxtbox_TextChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(41, 49);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(112, 16);
            this.label32.TabIndex = 26;
            this.label32.Text = "Total Deductions:";
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox7.Controls.Add(this.otxtbox);
            this.groupBox7.Controls.Add(this.sltxtbox);
            this.groupBox7.Controls.Add(this.fsltxtbox);
            this.groupBox7.Controls.Add(this.fsdtxtbox);
            this.groupBox7.Controls.Add(this.piltxtbox);
            this.groupBox7.Controls.Add(this.sssltxtbox);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.label26);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(464, 416);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(446, 227);
            this.groupBox7.TabIndex = 27;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "OTHER DEDUCTIONS";
            // 
            // otxtbox
            // 
            this.otxtbox.Location = new System.Drawing.Point(132, 180);
            this.otxtbox.Multiline = true;
            this.otxtbox.Name = "otxtbox";
            this.otxtbox.Size = new System.Drawing.Size(314, 22);
            this.otxtbox.TabIndex = 30;
            // 
            // sltxtbox
            // 
            this.sltxtbox.Location = new System.Drawing.Point(129, 143);
            this.sltxtbox.Multiline = true;
            this.sltxtbox.Name = "sltxtbox";
            this.sltxtbox.Size = new System.Drawing.Size(311, 22);
            this.sltxtbox.TabIndex = 29;
            // 
            // fsltxtbox
            // 
            this.fsltxtbox.Location = new System.Drawing.Point(185, 114);
            this.fsltxtbox.Multiline = true;
            this.fsltxtbox.Name = "fsltxtbox";
            this.fsltxtbox.Size = new System.Drawing.Size(255, 22);
            this.fsltxtbox.TabIndex = 28;
            // 
            // fsdtxtbox
            // 
            this.fsdtxtbox.Location = new System.Drawing.Point(202, 84);
            this.fsdtxtbox.Multiline = true;
            this.fsdtxtbox.Name = "fsdtxtbox";
            this.fsdtxtbox.Size = new System.Drawing.Size(238, 22);
            this.fsdtxtbox.TabIndex = 27;
            // 
            // piltxtbox
            // 
            this.piltxtbox.Location = new System.Drawing.Point(143, 54);
            this.piltxtbox.Multiline = true;
            this.piltxtbox.Name = "piltxtbox";
            this.piltxtbox.Size = new System.Drawing.Size(297, 22);
            this.piltxtbox.TabIndex = 26;
            // 
            // sssltxtbox
            // 
            this.sssltxtbox.Location = new System.Drawing.Point(126, 27);
            this.sssltxtbox.Multiline = true;
            this.sssltxtbox.Name = "sssltxtbox";
            this.sssltxtbox.Size = new System.Drawing.Size(314, 22);
            this.sssltxtbox.TabIndex = 21;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(41, 180);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(49, 16);
            this.label31.TabIndex = 25;
            this.label31.Text = "Others:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(41, 146);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(82, 16);
            this.label30.TabIndex = 24;
            this.label30.Text = "Salary Loan:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(41, 117);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(138, 16);
            this.label29.TabIndex = 23;
            this.label29.Text = "Faculty Savings Loan:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(41, 87);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(155, 16);
            this.label28.TabIndex = 22;
            this.label28.Text = "Faculty Savings Deposit:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(41, 57);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(96, 16);
            this.label27.TabIndex = 21;
            this.label27.Text = "PAGIBIG Loan:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(41, 30);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(70, 16);
            this.label26.TabIndex = 20;
            this.label26.Text = "SSS Loan:";
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox6.Controls.Add(this.ttxtbox);
            this.groupBox6.Controls.Add(this.pctxtbox);
            this.groupBox6.Controls.Add(this.phctxtbox);
            this.groupBox6.Controls.Add(this.sssctxtbox);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(464, 275);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(446, 135);
            this.groupBox6.TabIndex = 26;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "REGULARDEDUCTIONS";
            // 
            // ttxtbox
            // 
            this.ttxtbox.Location = new System.Drawing.Point(195, 104);
            this.ttxtbox.Multiline = true;
            this.ttxtbox.Name = "ttxtbox";
            this.ttxtbox.Size = new System.Drawing.Size(246, 22);
            this.ttxtbox.TabIndex = 24;
            // 
            // pctxtbox
            // 
            this.pctxtbox.Location = new System.Drawing.Point(177, 79);
            this.pctxtbox.Multiline = true;
            this.pctxtbox.Name = "pctxtbox";
            this.pctxtbox.Size = new System.Drawing.Size(264, 22);
            this.pctxtbox.TabIndex = 23;
            this.pctxtbox.TextChanged += new System.EventHandler(this.pctxtbox_TextChanged);
            // 
            // phctxtbox
            // 
            this.phctxtbox.Location = new System.Drawing.Point(195, 51);
            this.phctxtbox.Multiline = true;
            this.phctxtbox.Name = "phctxtbox";
            this.phctxtbox.Size = new System.Drawing.Size(245, 22);
            this.phctxtbox.TabIndex = 22;
            // 
            // sssctxtbox
            // 
            this.sssctxtbox.Location = new System.Drawing.Point(157, 24);
            this.sssctxtbox.Multiline = true;
            this.sssctxtbox.Name = "sssctxtbox";
            this.sssctxtbox.Size = new System.Drawing.Size(284, 22);
            this.sssctxtbox.TabIndex = 21;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(43, 110);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(153, 16);
            this.label25.TabIndex = 19;
            this.label25.Text = "Income Tax Contribution:";
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(41, 82);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(130, 16);
            this.label24.TabIndex = 18;
            this.label24.Text = "Pagibig Contribution:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(41, 54);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(148, 16);
            this.label23.TabIndex = 17;
            this.label23.Text = "Phil-Health Contribution:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(41, 27);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(110, 16);
            this.label22.TabIndex = 16;
            this.label22.Text = "SSS Contribution:";
            // 
            // cstxtbox
            // 
            this.cstxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cstxtbox.Location = new System.Drawing.Point(599, 128);
            this.cstxtbox.Multiline = true;
            this.cstxtbox.Name = "cstxtbox";
            this.cstxtbox.Size = new System.Drawing.Size(305, 22);
            this.cstxtbox.TabIndex = 35;
            // 
            // snametxtbox
            // 
            this.snametxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.snametxtbox.Location = new System.Drawing.Point(593, 100);
            this.snametxtbox.Multiline = true;
            this.snametxtbox.Name = "snametxtbox";
            this.snametxtbox.Size = new System.Drawing.Size(311, 22);
            this.snametxtbox.TabIndex = 34;
            // 
            // mnametxtbox
            // 
            this.mnametxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mnametxtbox.Location = new System.Drawing.Point(615, 72);
            this.mnametxtbox.Multiline = true;
            this.mnametxtbox.Name = "mnametxtbox";
            this.mnametxtbox.Size = new System.Drawing.Size(289, 22);
            this.mnametxtbox.TabIndex = 33;
            // 
            // fnametxtbox
            // 
            this.fnametxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.fnametxtbox.Location = new System.Drawing.Point(593, 44);
            this.fnametxtbox.Multiline = true;
            this.fnametxtbox.Name = "fnametxtbox";
            this.fnametxtbox.Size = new System.Drawing.Size(311, 22);
            this.fnametxtbox.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(518, 128);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 16);
            this.label5.TabIndex = 31;
            this.label5.Text = "Civil Status:";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(518, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 16);
            this.label4.TabIndex = 30;
            this.label4.Text = "Surname:";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(518, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 16);
            this.label3.TabIndex = 29;
            this.label3.Text = "Middle Name:";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(518, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 16);
            this.label2.TabIndex = 28;
            this.label2.Text = "Firstname:";
            // 
            // estxtbox
            // 
            this.estxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.estxtbox.Location = new System.Drawing.Point(636, 212);
            this.estxtbox.Multiline = true;
            this.estxtbox.Name = "estxtbox";
            this.estxtbox.Size = new System.Drawing.Size(268, 22);
            this.estxtbox.TabIndex = 40;
            this.estxtbox.TextChanged += new System.EventHandler(this.estxtbox_TextChanged);
            // 
            // nodtxtbox
            // 
            this.nodtxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nodtxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nodtxtbox.Location = new System.Drawing.Point(699, 156);
            this.nodtxtbox.Multiline = true;
            this.nodtxtbox.Name = "nodtxtbox";
            this.nodtxtbox.Size = new System.Drawing.Size(206, 22);
            this.nodtxtbox.TabIndex = 39;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(518, 215);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(112, 16);
            this.label9.TabIndex = 38;
            this.label9.Text = "Employee Status:";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(521, 187);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 16);
            this.label8.TabIndex = 37;
            this.label8.Text = "Paydate:";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(518, 156);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(180, 16);
            this.label7.TabIndex = 36;
            this.label7.Text = "Qualified Dependants Status:";
            // 
            // dtxtbox
            // 
            this.dtxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtxtbox.Location = new System.Drawing.Point(606, 240);
            this.dtxtbox.Multiline = true;
            this.dtxtbox.Name = "dtxtbox";
            this.dtxtbox.Size = new System.Drawing.Size(298, 22);
            this.dtxtbox.TabIndex = 43;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(518, 241);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 16);
            this.label6.TabIndex = 42;
            this.label6.Text = "Designation:";
            // 
            // newtxtbox
            // 
            this.newtxtbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.newtxtbox.BackColor = System.Drawing.Color.Maroon;
            this.newtxtbox.Location = new System.Drawing.Point(838, 751);
            this.newtxtbox.Name = "newtxtbox";
            this.newtxtbox.Size = new System.Drawing.Size(80, 32);
            this.newtxtbox.TabIndex = 44;
            this.newtxtbox.Text = "NEW";
            this.newtxtbox.UseVisualStyleBackColor = false;
            this.newtxtbox.Click += new System.EventHandler(this.newtxtbox_Click);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.Maroon;
            this.button1.Location = new System.Drawing.Point(762, 751);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 32);
            this.button1.TabIndex = 45;
            this.button1.Text = "UPDATE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.BackColor = System.Drawing.Color.Maroon;
            this.button2.Location = new System.Drawing.Point(692, 751);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(73, 32);
            this.button2.TabIndex = 46;
            this.button2.Text = "SAVE";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.BackColor = System.Drawing.Color.Maroon;
            this.button3.Location = new System.Drawing.Point(581, 751);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(113, 32);
            this.button3.TabIndex = 47;
            this.button3.Text = "NET INCOME";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button4.BackColor = System.Drawing.Color.Maroon;
            this.button4.Location = new System.Drawing.Point(451, 751);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(136, 32);
            this.button4.TabIndex = 48;
            this.button4.Text = "GROSS INCOME";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label33
            // 
            this.label33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(280, 9);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(342, 32);
            this.label33.TabIndex = 50;
            this.label33.Text = "CVR7 CHOICE PAYROLL";
            // 
            // label34
            // 
            this.label34.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(21, 42);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(117, 16);
            this.label34.TabIndex = 51;
            this.label34.Text = "EMPLOYEE INFO:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = global::RODRIGUEZ_LESSON1.Properties.Resources.default_avatar_icon_of_social_media_user_vector;
            this.pictureBox1.Location = new System.Drawing.Point(24, 61);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(181, 170);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePicker1.Location = new System.Drawing.Point(593, 187);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(311, 22);
            this.dateTimePicker1.TabIndex = 52;
            // 
            // Activity5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(919, 790);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.newtxtbox);
            this.Controls.Add(this.dtxtbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.estxtbox);
            this.Controls.Add(this.nodtxtbox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cstxtbox);
            this.Controls.Add(this.snametxtbox);
            this.Controls.Add(this.mnametxtbox);
            this.Controls.Add(this.fnametxtbox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.deptxtbox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.employeetxtbox);
            this.Controls.Add(this.label1);
            this.Name = "Activity5";
            this.Text = "Activity5";
            this.Load += new System.EventHandler(this.Activity5_Load);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox employeetxtbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox deptxtbox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox nitxtbox;
        private System.Windows.Forms.TextBox gitxtbox;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox ico3txtbox;
        private System.Windows.Forms.TextBox nhco3txtbox;
        private System.Windows.Forms.TextBox rate3txtbox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox ico2txtbox;
        private System.Windows.Forms.TextBox nhco2txtbox;
        private System.Windows.Forms.TextBox rate2txtbox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox ico1txtbox;
        private System.Windows.Forms.TextBox nhco1txtbox;
        private System.Windows.Forms.TextBox rate1txtbox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox tdtxtbox;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox otxtbox;
        private System.Windows.Forms.TextBox sltxtbox;
        private System.Windows.Forms.TextBox fsltxtbox;
        private System.Windows.Forms.TextBox fsdtxtbox;
        private System.Windows.Forms.TextBox piltxtbox;
        private System.Windows.Forms.TextBox sssltxtbox;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox ttxtbox;
        private System.Windows.Forms.TextBox pctxtbox;
        private System.Windows.Forms.TextBox phctxtbox;
        private System.Windows.Forms.TextBox sssctxtbox;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox cstxtbox;
        private System.Windows.Forms.TextBox snametxtbox;
        private System.Windows.Forms.TextBox mnametxtbox;
        private System.Windows.Forms.TextBox fnametxtbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox estxtbox;
        private System.Windows.Forms.TextBox nodtxtbox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox dtxtbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button newtxtbox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}